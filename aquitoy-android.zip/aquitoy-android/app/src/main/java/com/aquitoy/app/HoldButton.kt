package com.aquitoy.app

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Botón de ayuda que hay que MANTENER pulsado 2 segundos, para que no se active por un toque accidental.
 * Mientras se pulsa, una barra oscura va llenando el botón.
 */
class HoldButton(ctx: Context, private val onTrigger: () -> Unit) : FrameLayout(ctx) {
    private val holdMs = 2000L
    private val fill = View(ctx)
    private val title: TextView = ctx.label("AYUDA (mantén pulsado)", 18f, Color.WHITE, true, true)
    private val sub: TextView = ctx.label("Sin soltar durante 2 segundos", 14f, Color.WHITE, false, true)
    private var anim: ValueAnimator? = null
    private var completed = false

    init {
        background = shape(Pal.RED, ctx.dp(20).toFloat())
        fill.background = shape(Color.parseColor("#7F1912"), ctx.dp(20).toFloat())
        fill.pivotX = 0f
        fill.scaleX = 0f
        addView(fill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(ctx.dp(12), ctx.dp(4), ctx.dp(12), ctx.dp(4))
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(sub, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        isClickable = true
        contentDescription = "Botón de ayuda. Mantén pulsado dos segundos para pedir ayuda."
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                completed = false
                parent?.requestDisallowInterceptTouchEvent(true)
                start()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                if (!completed) {
                    cancelAnim()
                    sub.text = "Mantén pulsado más tiempo"
                }
                return true
            }
        }
        return true
    }

    /** Para quien usa TalkBack: tocar dos veces abre directamente la pantalla de ayuda. */
    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun start() {
        cancelAnim()
        sub.text = "Sigue pulsando…"
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = holdMs
        a.addUpdateListener { fill.scaleX = it.animatedValue as Float }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) {
                    completed = true
                    sub.text = "Sin soltar durante 2 segundos"
                    fill.scaleX = 0f
                    onTrigger()
                }
            }
        })
        anim = a
        a.start()
    }

    private fun cancelAnim() {
        anim?.cancel()
        anim = null
        fill.scaleX = 0f
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        cancelAnim()
    }
}
