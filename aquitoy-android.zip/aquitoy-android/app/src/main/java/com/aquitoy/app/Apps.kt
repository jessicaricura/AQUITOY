package com.aquitoy.app

import android.graphics.Color

data class AppDef(val id: String, val label: String, val color: Int, val icon: Int)

object Apps {
    val all: List<AppDef> = listOf(
        AppDef("llamar", "Llamar", Color.parseColor("#1456B8"), R.drawable.ic_phone),
        AppDef("whatsapp", "WhatsApp", Color.parseColor("#1B6E3C"), R.drawable.ic_chat),
        AppDef("mensajes", "Mensajes", Color.parseColor("#9B2C6B"), R.drawable.ic_sms),
        AppDef("avisos", "Avisos", Color.parseColor("#B34A00"), R.drawable.ic_bell),
        AppDef("correo", "Correo", Color.parseColor("#33509E"), R.drawable.ic_mail),
        AppDef("fotos", "Fotos", Color.parseColor("#6A3FA0"), R.drawable.ic_image),
        AppDef("camara", "Cámara", Color.parseColor("#3B4A5A"), R.drawable.ic_camera),
        AppDef("contactos", "Contactos", Color.parseColor("#00696B"), R.drawable.ic_user),
        AppDef("buscar", "Buscar", Color.parseColor("#2B5A7A"), R.drawable.ic_search),
        AppDef("notas", "Notas", Color.parseColor("#7A5B00"), R.drawable.ic_note),
        AppDef("alarma", "Alarma", Color.parseColor("#8C2F39"), R.drawable.ic_alarm),
        AppDef("recordatorios", "Recordatorios", Color.parseColor("#A24A00"), R.drawable.ic_bell)
    )
}
