package com.aquitoy.app

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.TypedValue
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Switch

/** Ajustes para la familia: datos, apps visibles, voz, clave de Claude y permisos. */
class SettingsActivity : BaseActivity() {
    private lateinit var nameInput: EditText
    private val famName = ArrayList<EditText>()
    private val famPhone = ArrayList<EditText>()
    private lateinit var rateBar: SeekBar
    private lateinit var keyInput: EditText
    private lateinit var readSwitch: Switch
    private var speaker: Speaker? = null
    private var first = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        first = intent.getBooleanExtra("first", false)
        val c = makeScreen(if (first) "Vamos a empezar" else "Ajustes para la familia", !first)

        c.addV(label("Esta pantalla es para la familia. Los datos se guardan solo en este móvil.", 20f, Pal.MUTED))

        c.addV(label("Nombre de la persona", 20f, Pal.INK, true), 16)
        nameInput = input("Nombre", Store.name(this))
        c.addV(nameInput, 6)

        val family = Store.family(this)
        for (i in 0 until 3) {
            val title = if (i == 0) "Contacto de emergencia (botón de ayuda)" else "Familiar " + (i + 1)
            c.addV(label(title, 20f, Pal.INK, true), 16)
            val n = input("Nombre", family[i].name)
            val p = input("Teléfono", family[i].phone, InputType.TYPE_CLASS_PHONE)
            famName.add(n)
            famPhone.add(p)
            c.addV(n, 6)
            c.addV(p, 8)
        }

        c.addV(bigButton("Personalizar la pantalla (fondo, letra, botones)", Pal.BLUE) {
            startActivity(Intent(this, AppearanceActivity::class.java))
        }, 24)

        c.addV(label("Velocidad de la voz", 22f, Pal.INK, true), 24)
        rateBar = SeekBar(this)
        rateBar.max = 6
        rateBar.progress = Math.round((Store.rate(this) - 0.6f) * 10f).coerceIn(0, 6)
        c.addV(rateBar, 6)
        c.addV(smallButton("Probar la voz", android.graphics.Color.WHITE, Pal.INK) { testVoice() }, 8)

        readSwitch = Switch(this)
        readSwitch.text = "Leer en voz alta los avisos de WhatsApp y mensajes"
        readSwitch.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        readSwitch.setTextColor(Pal.INK)
        readSwitch.isChecked = Store.readNotices(this)
        c.addV(readSwitch, 16)

        c.addV(label("Clave de Claude (para el asistente)", 20f, Pal.INK, true), 20)
        keyInput = input("sk-ant-...", Store.apiKey(this), InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        c.addV(keyInput, 6)
        c.addV(label("Se guarda solo en este móvil. No la compartas.", 17f, Pal.MUTED), 4)

        c.addV(label("Permisos y funciones", 22f, Pal.INK, true), 24)
        c.addV(smallButton("1. Dar permisos (llamadas, contactos, micrófono, avisos)", android.graphics.Color.WHITE, Pal.INK) { requestAllPermissions() }, 8)
        c.addV(smallButton("2. Acceso a notificaciones (avisos de WhatsApp y llamadas)", android.graphics.Color.WHITE, Pal.INK) {
            openSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        }, 8)
        c.addV(smallButton("3. Alarmas y avisos a pantalla completa", android.graphics.Color.WHITE, Pal.INK) { fullScreenSettings() }, 8)
        c.addV(smallButton("4. No restringir la batería (para que suenen los avisos)", android.graphics.Color.WHITE, Pal.INK) { batterySettings() }, 8)
        c.addV(smallButton("5. Usar AQUITOY como pantalla de inicio del móvil", android.graphics.Color.WHITE, Pal.INK) {
            setHomeEnabled(true)
            openHomeSettings()
        }, 8)
        c.addV(smallButton("Dejar de usar AQUITOY como pantalla de inicio", android.graphics.Color.WHITE, Pal.RED) {
            stopBeingHome()
        }, 8)
        c.addV(smallButton("Probar una alarma (suena en 10 segundos)", android.graphics.Color.WHITE, Pal.INK) {
            Scheduler.test(this)
            toast("Sonará en 10 segundos. Puedes salir de la app para probarlo.")
        }, 8)

        val err = ErrorLog.last(this)
        if (err.isNotEmpty()) {
            c.addV(label("Último error de la app (si falla, haz una captura de esto)", 20f, Pal.INK, true), 28)
            c.addV(label(err, 13f, Pal.MUTED), 6)
            c.addV(smallButton("Borrar este mensaje", android.graphics.Color.WHITE, Pal.INK) {
                ErrorLog.clear(this)
                toast("Borrado")
            }, 8)
        }

        c.addV(bigButton("Guardar", Pal.BLUE) { save() }, 24)
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            toast("No puedo abrir esa pantalla. Búscala en Ajustes de Android.")
        }
    }

    private fun fullScreenSettings() {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                val i = Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT)
                i.data = Uri.parse("package:$packageName")
                startActivity(i)
            } else {
                toast("En este móvil no hace falta ajustar nada aquí")
            }
        } catch (e: Exception) {
            toast("Busca en Ajustes de Android > Aplicaciones > AQUITOY > Notificaciones")
        }
    }

    private fun batterySettings() {
        try {
            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            i.data = Uri.parse("package:$packageName")
            startActivity(i)
        } catch (e: Exception) {
            openSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        }
    }

    private fun currentRate(): Float = 0.6f + rateBar.progress / 10f

    private fun testVoice() {
        Store.setRate(this, currentRate())
        speaker?.shutdown()
        val sp = Speaker(this)
        speaker = sp
        val n = nameInput.text.toString().trim()
        sp.speak("Hola" + (if (n.isNotEmpty()) ", $n" else "") + ". Así es como te voy a hablar.", true, null)
    }

    private fun save() {
        Store.setName(this, nameInput.text.toString().trim().take(40))
        val list = ArrayList<Contact>()
        for (i in 0 until 3) {
            list.add(Contact(famName[i].text.toString().trim().take(40), famPhone[i].text.toString().trim().take(25)))
        }
        Store.setFamily(this, list)
        Store.setRate(this, currentRate())
        Store.setReadNotices(this, readSwitch.isChecked)
        Store.setApiKey(this, keyInput.text.toString().trim())
        if (first) {
            Store.setSetupDone(this, true)
            requestAllPermissions()
        }
        Scheduler.rescheduleAll(this)
        toast("Guardado")
        finish()
    }

    override fun onDestroy() {
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }
}
