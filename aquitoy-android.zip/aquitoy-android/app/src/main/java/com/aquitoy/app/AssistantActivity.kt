package com.aquitoy.app

import android.Manifest
import android.animation.ValueAnimator
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Asistente de voz: habla, escucha, y conversa con Claude.
 * Usa el micrófono de Android con permiso real (en la web no era posible).
 */
class AssistantActivity : BaseActivity() {
    private val main = Handler(Looper.getMainLooper())
    private var speaker: Speaker? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = ArrayList<Pair<String, String>>()
    private var active = false
    private var busy = false
    private var silence = 0
    private var failures = 0
    private var pulse: ValueAnimator? = null
    private var localMode = false

    private lateinit var orb: View
    private lateinit var statusTv: TextView
    private lateinit var hintTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Mi asistente")
        c.gravity = Gravity.CENTER_HORIZONTAL
        // Evita que la pantalla se desplace sola y tape el círculo.
        val sv = root.getChildAt(2) as? android.widget.ScrollView
        if (sv != null) {
            sv.isFocusable = false
            sv.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            sv.post { sv.scrollTo(0, 0) }
        }

        val holder = FrameLayout(this)
        orb = View(this)
        orb.background = shape(Pal.BLUE, dp(80).toFloat())
        val olp = FrameLayout.LayoutParams(dp(160), dp(160))
        olp.gravity = Gravity.CENTER
        holder.addView(orb, olp)
        val mic = icon(R.drawable.ic_mic, 72, Color.WHITE)
        val mlp = FrameLayout.LayoutParams(dp(72), dp(72))
        mlp.gravity = Gravity.CENTER
        holder.addView(mic, mlp)
        holder.setOnClickListener { onOrbTap() }
        holder.contentDescription = "Tocar para hablar con el asistente"
        c.addV(holder, 28, dp(260))

        statusTv = label("Preparando…", 38f, Pal.INK, true, true)
        c.addV(statusTv, 8)
        hintTv = label("", 22f, Pal.MUTED, false, true)
        c.addV(hintTv, 8)

        c.addV(bigButton("Terminar de hablar", Color.WHITE, Pal.INK, Pal.INK) { finish() }, 36)

        speaker = Speaker(this)

        localMode = Store.apiKey(this).isBlank()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            setStatus("Este móvil no puede escucharte", "Instala o activa la app Google para tener reconocimiento de voz.")
            return
        }
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 600)
            setStatus("Necesito el micrófono", "Pulsa Permitir en la pantalla que aparece.")
            return
        }
        begin()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 600) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (!active) begin()
            } else {
                setStatus("Sin micrófono no puedo escucharte", "Actívalo en Ajustes de Android > Aplicaciones > AQUITOY > Permisos.")
            }
        }
    }

    private fun setStatus(title: String, hint: String) {
        statusTv.text = title
        hintTv.text = hint
    }

    private fun setPulse(on: Boolean) {
        pulse?.cancel()
        pulse = null
        orb.scaleX = 1f
        orb.scaleY = 1f
        if (!on) return
        val a = ValueAnimator.ofFloat(1f, 1.18f)
        a.duration = 700
        a.repeatMode = ValueAnimator.REVERSE
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val v = it.animatedValue as Float
            orb.scaleX = v
            orb.scaleY = v
        }
        a.start()
        pulse = a
    }

    private fun begin() {
        active = true
        silence = 0
        failures = 0
        val name = Store.name(this)
        val hello = greeting() + (if (name.isNotBlank()) ", $name" else "") +
            ". ¿Cómo estás hoy?"
        if (localMode) LocalBrain.reset()
        say(hello) { listen() }
    }

    private fun say(text: String, then: (() -> Unit)?) {
        setStatus("Te hablo", "Toca el círculo si quieres interrumpirme.")
        setPulse(true)
        val sp = speaker
        if (sp == null) {
            then?.invoke()
            return
        }
        sp.speak(text, true) {
            setPulse(false)
            if (active && then != null) then()
        }
    }

    private fun onOrbTap() {
        if (!active) {
            if (hasPerm(Manifest.permission.RECORD_AUDIO)) begin()
            return
        }
        // Interrumpir: dejamos de hablar y escuchamos.
        speaker?.stop()
        destroyRecognizer()
        setPulse(false)
        main.postDelayed({ if (active && !busy) listen() }, 250)
    }

    private fun destroyRecognizer() {
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
            // nada
        }
        recognizer = null
    }

    private fun listen() {
        if (!active || isFinishing) return
        destroyRecognizer()
        setStatus("Te escucho", "Habla con calma, como si hablaras con una amiga.")
        setPulse(true)
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                setPulse(false)
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> onSilence()
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                        active = false
                        setStatus("Necesito el micrófono", "Actívalo en Ajustes de Android > Aplicaciones > AQUITOY > Permisos.")
                    }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                        main.postDelayed({ if (active && !busy) listen() }, 800)
                    }
                    else -> {
                        failures += 1
                        if (failures >= 3) {
                            active = false
                            setStatus("No consigo oírte", "Comprueba la conexión a internet y toca el círculo.")
                        } else {
                            main.postDelayed({ if (active && !busy) listen() }, 800)
                        }
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                setPulse(false)
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()?.trim() ?: ""
                if (text.isEmpty()) onSilence() else onHeard(text)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        try {
            r.startListening(i)
        } catch (e: Exception) {
            setStatus("No puedo usar el micrófono", "Cierra otras apps que lo usen y toca el círculo.")
            active = false
        }
    }

    private fun onSilence() {
        silence += 1
        if (silence == 2) {
            say("¿Sigues ahí? Dime algo cuando quieras.") { listen() }
        } else if (silence >= 4) {
            active = false
            say("Parece que ahora no quieres hablar. Aquí estaré cuando me necesites.", null)
            setStatus("Toca el círculo para hablar", "")
        } else {
            listen()
        }
    }

    private fun onHeard(text: String) {
        silence = 0
        busy = true
        setStatus("Pensando…", "Un momento, por favor.")
        setPulse(false)
        history.add(Pair("user", text))
        val snapshot = ArrayList(history)
        if (localMode) {
            val local = LocalBrain.reply(applicationContext, text)
            main.postDelayed({ onReply(local, null) }, 300)
            return
        }
        Thread {
            var reply: ClaudeReply? = null
            var err: ClaudeException? = null
            try {
                reply = Claude.chat(applicationContext, snapshot)
            } catch (e: ClaudeException) {
                err = e
            } catch (e: Exception) {
                err = ClaudeException(-1, "Sin conexión")
            }
            main.post { onReply(reply, err) }
        }.start()
    }

    private fun onReply(reply: ClaudeReply?, err: ClaudeException?) {
        busy = false
        if (!active || isFinishing) return
        if (reply == null) {
            history.removeAt(history.size - 1)
            failures += 1
            val msg = when {
                err != null && (err.code == 401 || err.code == 403) -> "La clave de Claude no es correcta. Un familiar debe revisarla en Ajustes."
                failures >= 3 -> "Parece que no tengo conexión ahora mismo. Inténtalo un poco más tarde."
                else -> "Perdona, no te he podido atender bien. ¿Me lo repites?"
            }
            if (failures >= 3 || (err != null && (err.code == 401 || err.code == 403))) {
                active = false
                say(msg, null)
                setStatus("No puedo hablar con Claude", msg)
            } else {
                say(msg) { listen() }
            }
            return
        }
        failures = 0

        var end = false
        var openId: String? = null
        val notes = ArrayList<String>()
        for (a in reply.actions) {
            when (a.name) {
                "guardar_recuerdo" -> Store.remember(applicationContext, a.input.optString("texto"))
                "crear_recordatorio" -> {
                    val n = createReminder(a)
                    if (n != null) notes.add(n)
                }
                "fin_conversacion" -> end = true
                "abrir" -> openId = a.input.optString("que")
            }
        }
        var out = reply.text
        if (out.isBlank()) {
            out = if (notes.isNotEmpty()) notes.joinToString(" ") else if (end) "Hasta pronto." else "Cuéntame más, te escucho."
        }
        history.add(Pair("assistant", out))
        say(out) {
            val target = openId
            if (end) {
                active = false
                finish()
            } else if (target != null && target.isNotEmpty()) {
                active = false
                openAppById(target)
                finish()
            } else {
                listen()
            }
        }
    }

    private fun createReminder(a: ClaudeAction): String? {
        val hora = a.input.optString("hora").trim()
        val m = Regex("^([01]?\\d|2[0-3]):([0-5]\\d)$").find(hora) ?: return null
        val h = m.groupValues[1].toInt()
        val min = m.groupValues[2].toInt()
        val texto = a.input.optString("texto").trim()
        if (texto.isEmpty()) return null
        val tomorrow = a.input.optString("dia") == "manana"
        val daily = a.input.optBoolean("cada_dia", false)
        Scheduler.create(applicationContext, h, min, texto, daily, false, tomorrow)
        return "Hecho. Te avisaré a las " + String.format("%02d:%02d", h, min) + "."
    }

    override fun onDestroy() {
        active = false
        pulse?.cancel()
        main.removeCallbacksAndMessages(null)
        destroyRecognizer()
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }
}
