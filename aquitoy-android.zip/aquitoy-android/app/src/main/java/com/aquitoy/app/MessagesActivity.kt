package com.aquitoy.app

import android.os.Bundle

/**
 * Mensajes sin permisos delicados: abre la app de mensajes del móvil.
 * (Leer los SMS desde aquí exigiría un permiso "restringido" que Android bloquea en apps instaladas por APK.)
 */
class MessagesActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Mensajes")
        c.addV(label("Aquí puedes leer y escribir tus mensajes de texto.", 24f, Pal.INK))
        c.addV(bigButton("Abrir mis mensajes", Pal.BLUE) { openSmsApp(); }, 24)
        c.addV(bigButton("Escribir un mensaje nuevo", Pal.GREEN) { openSmsApp() }, 14)
        c.addV(bigButton("Mensajes de WhatsApp", Pal.GREEN) { openWhatsApp() }, 14)
        c.addV(label("Los avisos de WhatsApp y llamadas están en el botón Avisos.", 20f, Pal.MUTED), 20)
    }
}
