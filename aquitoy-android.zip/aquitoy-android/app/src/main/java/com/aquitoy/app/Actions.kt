package com.aquitoy.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun Context.hasPerm(p: String): Boolean =
    checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

fun Context.toast(s: String) {
    Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}

/** Pide todos los permisos que la app necesita para funcionar de verdad. */
fun Activity.requestAllPermissions() {
    val list = ArrayList<String>()
    list.add(Manifest.permission.CALL_PHONE)
    list.add(Manifest.permission.READ_CONTACTS)
    list.add(Manifest.permission.RECORD_AUDIO)
    if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
    val missing = list.filter { !hasPerm(it) }
    if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 100)
}

fun cleanNumber(raw: String): String = raw.filter { it.isDigit() || it == '+' }

/** Número para wa.me: solo dígitos y con prefijo de país (España por defecto). */
fun waNumber(raw: String): String {
    val c = cleanNumber(raw)
    if (c.startsWith("+")) return c.substring(1)
    if (c.startsWith("00")) return c.substring(2)
    val z = c.trimStart('0')
    return if (z.length == 9) "34$z" else z
}

/** Llama directamente si hay permiso; si no, abre el marcador con el número puesto. */
fun Activity.callNow(number: String) {
    val uri = Uri.parse("tel:" + Uri.encode(cleanNumber(number)))
    try {
        if (hasPerm(Manifest.permission.CALL_PHONE)) {
            startActivity(Intent(Intent.ACTION_CALL, uri))
        } else {
            startActivity(Intent(Intent.ACTION_DIAL, uri))
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), 101)
        }
    } catch (e: Exception) {
        toast("No se puede llamar desde este dispositivo")
    }
}

private val WHATSAPP_PACKAGES = listOf("com.whatsapp", "com.whatsapp.w4b")

/** Abre WhatsApp directamente (el permiso <queries> del manifiesto es lo que lo hace fiable). */
fun Activity.openWhatsApp() {
    for (pkg in WHATSAPP_PACKAGES) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // probamos con la siguiente
            }
        }
    }
    toast("WhatsApp no está instalado. Te abro la tienda para instalarlo.")
    openUrl("https://play.google.com/store/apps/details?id=com.whatsapp")
}

/** Abre el chat de WhatsApp con un número concreto. */
fun Activity.openWhatsAppChat(number: String) {
    val uri = Uri.parse("https://wa.me/" + waNumber(number))
    for (pkg in WHATSAPP_PACKAGES) {
        if (packageManager.getLaunchIntentForPackage(pkg) != null) {
            try {
                val i = Intent(Intent.ACTION_VIEW, uri)
                i.setPackage(pkg)
                startActivity(i)
                return
            } catch (e: Exception) {
                // probamos con la siguiente
            }
        }
    }
    openWhatsApp()
}

fun Activity.openUrl(url: String) {
    try {
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    } catch (e: ActivityNotFoundException) {
        toast("No encuentro ninguna app para abrir esto")
    }
}

/** Abre una app instalada por su nombre de paquete. Devuelve false si no está instalada. */
fun Activity.openPackage(pkg: String): Boolean {
    val i = packageManager.getLaunchIntentForPackage(pkg) ?: return false
    return try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        true
    } catch (e: Exception) {
        false
    }
}

fun Activity.openGallery() {
    try {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_APP_GALLERY)
        startActivity(i)
    } catch (e: Exception) {
        try {
            val j = Intent(Intent.ACTION_VIEW)
            j.type = "image/*"
            startActivity(j)
        } catch (e2: Exception) {
            toast("No encuentro la galería de fotos")
        }
    }
}

fun Activity.openCamera() {
    try {
        startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE))
    } catch (e: Exception) {
        toast("No encuentro la cámara")
    }
}

fun Activity.openSmsApp(number: String? = null) {
    try {
        val uri = if (number == null) Uri.parse("smsto:") else Uri.parse("smsto:" + Uri.encode(cleanNumber(number)))
        startActivity(Intent(Intent.ACTION_SENDTO, uri))
    } catch (e: Exception) {
        toast("No encuentro la app de mensajes")
    }
}

fun formatTime(ts: Long): String =
    SimpleDateFormat("d MMM, HH:mm", Locale("es", "ES")).format(Date(ts))

fun greeting(): String {
    val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return if (h < 13) "Buenos días" else if (h < 21) "Buenas tardes" else "Buenas noches"
}

/** Abre el dictado de voz de Google. El resultado llega a onActivityResult con [requestCode]. */
@Suppress("DEPRECATION")
fun Activity.startDictation(requestCode: Int, prompt: String) {
    try {
        val i = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(
            android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
        i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, prompt)
        startActivityForResult(i, requestCode)
    } catch (e: Exception) {
        toast("Este móvil no tiene dictado por voz. Usa el micrófono del teclado.")
    }
}

/** Texto dictado a partir del resultado de [startDictation], o null. */
fun dictatedText(data: Intent?): String? {
    val list = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
    return list?.firstOrNull()
}

/** Abre la pantalla de Android donde se elige la app de inicio. */
fun Activity.openHomeSettings() {
    try {
        startActivity(Intent(android.provider.Settings.ACTION_HOME_SETTINGS))
    } catch (e: Exception) {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            toast("Busca: Aplicaciones > Aplicaciones predeterminadas > App de inicio, y elige AQUITOY")
        } catch (e2: Exception) {
            toast("Abre los Ajustes del móvil y busca App de inicio")
        }
    }
}

private const val HOME_ALIAS = "com.aquitoy.app.HomeAlias"

/** ¿Está AQUITOY ofreciéndose como pantalla de inicio? (se puede apagar con el botón de Ajustes) */
fun Context.homeEnabled(): Boolean {
    return try {
        val st = packageManager.getComponentEnabledSetting(android.content.ComponentName(this, HOME_ALIAS))
        st != android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED
    } catch (e: Exception) {
        true
    }
}

fun Context.setHomeEnabled(on: Boolean) {
    try {
        packageManager.setComponentEnabledSetting(
            android.content.ComponentName(this, HOME_ALIAS),
            if (on) android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            else android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
            android.content.pm.PackageManager.DONT_KILL_APP
        )
    } catch (e: Exception) {
        toast("No he podido cambiarlo")
    }
}

/** Abre una de las apps de AQUITOY por su nombre interno (lo usa el inicio y el asistente de voz). */
fun Activity.openAppById(id: String) {
    when (id) {
        "llamar" -> startActivity(Intent(this, ContactsActivity::class.java).putExtra("call", true))
        "whatsapp" -> openWhatsApp()
        "mensajes" -> startActivity(Intent(this, MessagesActivity::class.java))
        "avisos" -> startActivity(Intent(this, NoticesActivity::class.java))
        "correo" -> startActivity(Intent(this, EmailActivity::class.java))
        "fotos" -> openGallery()
        "camara" -> openCamera()
        "contactos" -> startActivity(Intent(this, ContactsActivity::class.java))
        "buscar" -> startActivity(Intent(this, SearchActivity::class.java))
        "notas" -> startActivity(Intent(this, NotesActivity::class.java))
        "alarma" -> startActivity(Intent(this, RemindersActivity::class.java).putExtra("alarm", true))
        "recordatorios" -> startActivity(Intent(this, RemindersActivity::class.java))
        "calculadora" -> startActivity(Intent(this, CalculatorActivity::class.java))
        "personalizar" -> startActivity(Intent(this, AppearanceActivity::class.java))
        "playstore" -> if (!openPackage("com.android.vending")) openUrl("https://play.google.com/store")
        "youtube" -> if (!openPackage("com.google.android.youtube")) openUrl("https://www.youtube.com")
        "maps" -> if (!openPackage("com.google.android.apps.maps")) openUrl("https://maps.google.com")
        else -> if (id.startsWith("app:")) {
            if (!openPackage(id.removePrefix("app:"))) toast("No puedo abrir esa app. Puede que se haya desinstalado.")
        }
    }
}

/** Deja de ofrecer AQUITOY como pantalla de inicio y vuelve a la del móvil de antes. */
fun Activity.stopBeingHome() {
    setHomeEnabled(false)
    toast("Listo. Pulsa el botón de inicio del móvil para volver a tu pantalla de antes.")
    try {
        val i = Intent(Intent.ACTION_MAIN)
        i.addCategory(Intent.CATEGORY_HOME)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    } catch (e: Exception) {
        // nada
    }
}
