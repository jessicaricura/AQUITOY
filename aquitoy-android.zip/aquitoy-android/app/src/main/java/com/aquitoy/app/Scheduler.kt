package com.aquitoy.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Programa los avisos con setAlarmClock: Android los respeta aunque la app esté cerrada,
 * la pantalla apagada o el móvil en ahorro de batería, y no pide permiso especial.
 */
object Scheduler {

    /** Próximo momento con esa hora. Si [tomorrow] es true, siempre mañana. */
    fun nextTrigger(hour: Int, minute: Int, tomorrow: Boolean = false): Long {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (tomorrow) cal.add(Calendar.DAY_OF_YEAR, 1)
        if (cal.timeInMillis <= now) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun pending(c: Context, id: Long): PendingIntent {
        val i = Intent(c, ReminderReceiver::class.java)
        i.putExtra("id", id)
        val code = (id % 1000000007L).toInt()
        return PendingIntent.getBroadcast(
            c, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, r: Reminder) {
        if (!r.enabled) {
            cancel(c, r.id)
            return
        }
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(r.triggerAt, show), pending(c, r.id))
        } catch (e: Exception) {
            // Si el móvil no permite alarmas exactas, usamos un aviso normal para que al menos suene.
            try {
                am.set(AlarmManager.RTC_WAKEUP, r.triggerAt, pending(c, r.id))
            } catch (e2: Exception) {
                ErrorLog.save(c, e2)
            }
        }
    }

    fun cancel(c: Context, id: Long) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, id))
    }

    /** Crea y programa un aviso nuevo. Devuelve el aviso guardado. */
    fun create(
        c: Context,
        hour: Int,
        minute: Int,
        text: String,
        daily: Boolean,
        alarm: Boolean,
        tomorrow: Boolean = false
    ): Reminder {
        val id = System.currentTimeMillis()
        val r = Reminder(id, hour, minute, text.take(120), daily, alarm, true, nextTrigger(hour, minute, tomorrow))
        Store.upsertReminder(c, r)
        schedule(c, r)
        return r
    }

    /** Aviso de prueba: suena en 10 segundos, para comprobar que el móvil deja sonar las alarmas. */
    fun test(c: Context) {
        val now = Calendar.getInstance()
        val r = Reminder(
            System.currentTimeMillis(), now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE),
            "Prueba de alarma", false, true, true, System.currentTimeMillis() + 10000L
        )
        Store.upsertReminder(c, r)
        schedule(c, r)
    }

    fun delete(c: Context, id: Long) {
        cancel(c, id)
        Store.removeReminder(c, id)
    }

    fun rescheduleAll(c: Context) {
        val now = System.currentTimeMillis()
        for (r in Store.reminders(c)) {
            if (!r.enabled) continue
            var next = r
            if (r.triggerAt <= now) {
                if (r.daily) {
                    next = r.copy(triggerAt = nextTrigger(r.hour, r.minute))
                    Store.upsertReminder(c, next)
                } else {
                    Store.upsertReminder(c, r.copy(enabled = false))
                    continue
                }
            }
            schedule(c, next)
        }
    }

    /** Texto del próximo aviso para mostrar en el inicio, o null si no hay. */
    fun nextLabel(c: Context): String? {
        val next = Store.reminders(c).filter { it.enabled }.minByOrNull { it.triggerAt } ?: return null
        return String.format("%02d:%02d", next.hour, next.minute) + " " + next.text
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Scheduler.rescheduleAll(context)
    }
}
