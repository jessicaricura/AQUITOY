package com.aquitoy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Hace sonar y hablar los avisos y alarmas aunque la app esté cerrada y la pantalla apagada.
 * Es un servicio en primer plano: Android lo permite cuando salta una alarma exacta.
 */
class AlarmService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var speaker: Speaker? = null
    private var wake: PowerManager.WakeLock? = null
    private var text = ""
    private var isAlarm = false
    private var spoken = 0
    private var stopped = false

    private val repeat = object : Runnable {
        override fun run() {
            if (stopped || spoken >= 8) return
            spoken += 1
            val phrase = if (isAlarm) "Alarma. $text" else "Recordatorio. $text"
            speaker?.speak(phrase, true, null)
            handler.postDelayed(this, 25000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            finishAll()
            return START_NOT_STICKY
        }
        releaseAll()
        stopped = false
        spoken = 0
        text = intent?.getStringExtra("text") ?: "Es la hora"
        isAlarm = intent?.getBooleanExtra("alarm", false) ?: false
        val hour = intent?.getIntExtra("hour", 0) ?: 0
        val minute = intent?.getIntExtra("minute", 0) ?: 0

        try {
            val n = buildNotification(hour, minute)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            ErrorLog.save(this, e)
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "aquitoy:alarm")
            w.acquire(3 * 60 * 1000L)
            wake = w
        } catch (e: Exception) {
            // sin wake lock
        }

        raiseVolume()
        startSound()
        startVibration()
        speaker = Speaker(this)
        handler.postDelayed(repeat, if (isAlarm) 2500 else 600)
        handler.postDelayed({ finishAll() }, 3 * 60 * 1000L)
        return START_NOT_STICKY
    }

    private fun buildNotification(hour: Int, minute: Int): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Alarmas sonando", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)

        val ring = Intent(this, RingActivity::class.java)
        ring.putExtra("text", text)
        ring.putExtra("alarm", isAlarm)
        ring.putExtra("hour", hour)
        ring.putExtra("minute", minute)
        ring.putExtra("viaService", true)
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val ringPi = PendingIntent.getActivity(this, 77, ring, flags)

        val stop = Intent(this, AlarmService::class.java)
        stop.action = ACTION_STOP
        val stopPi = PendingIntent.getService(this, 78, stop, flags)
        val action = Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_bell), "Parar", stopPi).build()

        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(if (isAlarm) "Alarma" else "Recordatorio")
            .setContentText(text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setOngoing(true)
            .setContentIntent(ringPi)
            .setFullScreenIntent(ringPi, true)
            .addAction(action)
            .build()
    }

    /** Si el volumen de alarmas está muy bajo, lo sube para que se oiga. */
    private fun raiseVolume() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val cur = am.getStreamVolume(AudioManager.STREAM_ALARM)
            val target = (max * 0.7f).toInt().coerceAtLeast(1)
            if (cur < target) am.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
        } catch (e: Exception) {
            // sin cambio de volumen
        }
    }

    private fun startSound() {
        try {
            val type = if (isAlarm) RingtoneManager.TYPE_ALARM else RingtoneManager.TYPE_NOTIFICATION
            var uri = RingtoneManager.getDefaultUri(type)
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = isAlarm
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            // Sin sonido: queda la voz.
        }
    }

    private fun startVibration() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            val repeatIndex = if (isAlarm) 0 else -1
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400, 600, 400), repeatIndex))
        } catch (e: Exception) {
            // sin vibración
        }
    }

    private fun releaseAll() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
        speaker?.shutdown()
        speaker = null
        try {
            player?.stop()
            player?.release()
        } catch (e: Exception) {
            // nada
        }
        player = null
        try {
            (getSystemService(Context.VIBRATOR_SERVICE) as Vibrator).cancel()
        } catch (e: Exception) {
            // nada
        }
        try {
            val w = wake
            if (w != null && w.isHeld) w.release()
        } catch (e: Exception) {
            // nada
        }
        wake = null
    }

    private fun finishAll() {
        releaseAll()
        try {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            // nada
        }
        stopSelf()
    }

    override fun onDestroy() {
        releaseAll()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "aquitoy_alarma_sonando"
        const val NOTIF_ID = 4242
        const val ACTION_STOP = "com.aquitoy.app.STOP_ALARM"

        fun start(c: Context, text: String, alarm: Boolean, hour: Int, minute: Int) {
            val i = Intent(c, AlarmService::class.java)
            i.putExtra("text", text)
            i.putExtra("alarm", alarm)
            i.putExtra("hour", hour)
            i.putExtra("minute", minute)
            c.startForegroundService(i)
        }

        fun stop(c: Context) {
            try {
                c.stopService(Intent(c, AlarmService::class.java))
            } catch (e: Exception) {
                // nada
            }
        }
    }
}
