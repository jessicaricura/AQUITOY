package com.aquitoy.app

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager

/** Pantalla grande que se muestra cuando llega la hora de un aviso o una alarma. El sonido lo hace AlarmService. */
class RingActivity : BaseActivity() {
    private var text = ""
    private var isAlarm = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        text = intent.getStringExtra("text") ?: "Es la hora"
        isAlarm = intent.getBooleanExtra("alarm", false)
        val hour = intent.getIntExtra("hour", 0)
        val minute = intent.getIntExtra("minute", 0)

        // Si el sonido no lo está haciendo ya el servicio (plan B), lo arrancamos desde aquí.
        if (!intent.getBooleanExtra("viaService", false)) {
            try {
                AlarmService.start(this, text, isAlarm, hour, minute)
            } catch (e: Exception) {
                ErrorLog.save(this, e)
            }
        }

        val c = makeScreen(if (isAlarm) "Alarma" else "Recordatorio", false)
        root.setBackgroundColor(Color.parseColor("#FFF4E5"))
        c.gravity = Gravity.CENTER_HORIZONTAL

        c.addV(icon(R.drawable.ic_bell, 96, Pal.AMBER), 24, dp(96))
        c.addV(label(String.format("%02d:%02d", hour, minute), 56f, Pal.INK, true, true), 8)
        c.addV(label(text, 32f, Pal.INK, true, true), 12)
        c.addV(bigButton("Ya lo he hecho", Pal.BLUE) { AlarmService.stop(this); finish() }, 40)
        c.addV(bigButton("Avísame en 10 minutos", Color.WHITE, Pal.INK, Pal.INK) { snooze() }, 14)
    }

    private fun snooze() {
        try {
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.MINUTE, 10)
            Scheduler.create(
                this, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE),
                text, false, isAlarm
            )
            toast("Te aviso en 10 minutos")
        } catch (e: Exception) {
            ErrorLog.save(this, e)
        }
        AlarmService.stop(this)
        finish()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Evitamos cerrar el aviso sin querer.
    }
}
