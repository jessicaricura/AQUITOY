package com.aquitoy.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.Context
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Pantalla de inicio. Si se elige como "aplicación de inicio", sustituye a la del móvil. */
class MainActivity : BaseActivity() {
    private lateinit var content: LinearLayout
    private lateinit var greetTv: TextView
    private lateinit var dateTv: TextView
    private lateinit var assistantSub: TextView
    private lateinit var grid: LinearLayout
    private var noticesSub: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Pal.BG)
        root.addV(TopBar(this))

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(20), dp(4), dp(20), dp(12))
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addV(scroll, 0, 0, 1f)

        // Cabecera: saludo + engranaje (hay que mantenerlo pulsado para abrir los ajustes)
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.TOP
        val texts = LinearLayout(this)
        texts.orientation = LinearLayout.VERTICAL
        dateTv = label("", 20f, Pal.MUTED)
        greetTv = label("", 32f, Pal.INK, true)
        texts.addView(dateTv)
        texts.addView(greetTv)
        head.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = android.widget.ImageButton(this)
        gear.setImageResource(R.drawable.ic_gear)
        gear.setColorFilter(Pal.INK)
        gear.contentDescription = "Ajustes para la familia. Mantén pulsado para abrir."
        gear.background = shape(Color.WHITE, dp(30).toFloat(), Pal.INK, dp(3))
        gear.setOnClickListener { toast("Mantén pulsado el engranaje para abrir los ajustes") }
        gear.setOnLongClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }
        head.addView(gear, LinearLayout.LayoutParams(dp(60), dp(60)))
        content.addV(head)

        // Tarjeta del asistente
        val assistant = LinearLayout(this)
        assistant.orientation = LinearLayout.HORIZONTAL
        assistant.gravity = Gravity.CENTER_VERTICAL
        assistant.setPadding(dp(16), dp(12), dp(16), dp(12))
        assistant.background = ripple(shape(Color.WHITE, dp(24).toFloat(), Pal.BLUE, dp(3)))
        assistant.setOnClickListener { startActivity(Intent(this, AssistantActivity::class.java)) }
        val micWrap = LinearLayout(this)
        micWrap.gravity = Gravity.CENTER
        micWrap.background = shape(Pal.BLUE, dp(28).toFloat())
        micWrap.addView(icon(R.drawable.ic_mic, 30, Color.WHITE), LinearLayout.LayoutParams(dp(30), dp(30)))
        assistant.addView(micWrap, LinearLayout.LayoutParams(dp(56), dp(56)))
        val at = LinearLayout(this)
        at.orientation = LinearLayout.VERTICAL
        at.addView(label("Mi asistente", 26f, Pal.INK, true))
        assistantSub = label("", 19f, Pal.MUTED)
        at.addView(assistantSub)
        val atlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        atlp.leftMargin = dp(16)
        assistant.addView(at, atlp)
        content.addV(assistant, 14)

        grid = LinearLayout(this)
        grid.orientation = LinearLayout.VERTICAL
        content.addV(grid, 14)

        val hold = HoldButton(this) { triggerSos() }
        val holdLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(100))
        holdLp.setMargins(dp(20), dp(8), dp(20), dp(14))
        root.addView(hold, holdLp)
        setContentView(root)

        if (!Store.setupDone(this)) {
            startActivity(Intent(this, SettingsActivity::class.java).putExtra("first", true))
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val name = Store.name(this)
        greetTv.text = greeting() + (if (name.isNotBlank()) ", $name" else "")
        val d = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "ES")).format(Date())
        dateTv.text = d.replaceFirstChar { it.uppercase() }
        val next = Scheduler.nextLabel(this)
        assistantSub.text = if (next != null) "Próximo aviso: $next" else "Habla conmigo cuando quieras"

        grid.removeAllViews()
        val visible = Store.visibleApps(this)
        val shown = Apps.all.filter { visible.contains(it.id) }
        if (shown.isEmpty()) {
            val note = card()
            note.addView(label("No hay apps. Mantén pulsado el engranaje para elegirlas.", 22f, Pal.MUTED))
            grid.addV(note)
            return
        }
        val noticeCount = Store.notices(this).size
        var i = 0
        while (i < shown.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.addH(tile(shown[i], noticeCount))
            if (i + 1 < shown.size) row.addH(tile(shown[i + 1], noticeCount), 14) else row.addH(android.view.View(this), 14)
            grid.addV(row, if (i == 0) 0 else 14)
            i += 2
        }
    }

    private fun tile(app: AppDef, noticeCount: Int): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(6), dp(10), dp(6), dp(10))
        t.minimumHeight = dp(110)
        t.background = ripple(shape(app.color, dp(24).toFloat()))
        t.addView(icon(app.icon, 42, Color.WHITE), LinearLayout.LayoutParams(dp(42), dp(42)))
        val text = if (app.id == "avisos" && noticeCount > 0) "Avisos ($noticeCount)" else app.label
        val lbl = label(text, 21f, Color.WHITE, true, true)
        t.addView(lbl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        t.setOnClickListener { open(app.id) }
        t.contentDescription = text
        return t
    }

    private fun open(id: String) {
        when (id) {
            "llamar" -> startActivity(Intent(this, ContactsActivity::class.java).putExtra("call", true))
            "whatsapp" -> openWhatsApp()
            "mensajes" -> startActivity(Intent(this, MessagesActivity::class.java))
            "avisos" -> startActivity(Intent(this, NoticesActivity::class.java))
            "correo" -> startActivity(Intent(this, EmailActivity::class.java))
            "fotos" -> openGallery()
            "camara" -> openCamera()
            "contactos" -> startActivity(Intent(this, ContactsActivity::class.java))
            "buscar" -> startActivity(Intent(this, SearchActivity::class.java))
            "notas" -> startActivity(Intent(this, NotesActivity::class.java))
            "alarma" -> startActivity(Intent(this, RemindersActivity::class.java).putExtra("alarm", true))
            "recordatorios" -> startActivity(Intent(this, RemindersActivity::class.java))
        }
    }

    private fun triggerSos() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
            // sin vibración
        }
        startActivity(Intent(this, SosActivity::class.java))
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Es la pantalla de inicio: no se sale de aquí con "atrás".
    }
}
