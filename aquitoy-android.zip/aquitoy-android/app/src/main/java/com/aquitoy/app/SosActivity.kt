package com.aquitoy.app

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Cuenta atrás de 10 segundos. Al llegar a 0 llama al contacto de emergencia. */
class SosActivity : BaseActivity() {
    private var timer: CountDownTimer? = null
    private var speaker: Speaker? = null
    private var done = false
    private lateinit var numTv: TextView
    private lateinit var msgTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val c = makeScreen("Pidiendo ayuda", false)
        root.setBackgroundColor(Color.parseColor("#FDEDEB"))
        c.gravity = Gravity.CENTER_HORIZONTAL

        val primary = Store.validFamily(this).firstOrNull()

        numTv = label("10", 110f, Pal.RED, true, true)
        c.addV(numTv, 8)
        c.addV(label("segundos", 22f, Pal.MUTED, false, true))
        val msg = if (primary != null)
            "Llamaré a ${primary.name}."
        else
            "No hay un contacto de emergencia guardado. Puedes llamar al 112 ahora."
        msgTv = label(msg, 24f, Pal.INK, false, true)
        c.addV(msgTv, 16)

        c.addV(bigButton("Llamar al 112 ahora", Pal.RED) { cancelTimer(); callNow("112"); finish() }, 28)
        if (primary != null) {
            c.addV(bigButton("Llamar a ${primary.name} ya", Pal.BLUE) { triggerNow() }, 12)
        }
        c.addV(bigButton("Cancelar, fue un error", Color.WHITE, Pal.INK, Pal.INK) { cancelAndClose() }, 12)

        vibrate()
        speaker = Speaker(this)
        if (primary != null) {
            speaker?.speak("Voy a pedir ayuda en diez segundos. Pulsa cancelar si ha sido un error.", true, null)
            startTimer()
        }
    }

    private fun startTimer() {
        timer = object : CountDownTimer(10000, 250) {
            override fun onTick(msLeft: Long) {
                numTv.text = ((msLeft + 999) / 1000).toString()
            }

            override fun onFinish() {
                numTv.text = "0"
                triggerNow()
            }
        }
        timer?.start()
    }

    private fun cancelTimer() {
        timer?.cancel()
        timer = null
    }

    private fun cancelAndClose() {
        cancelTimer()
        speaker?.stop()
        finish()
    }

    private fun triggerNow() {
        if (done) return
        done = true
        cancelTimer()
        val primary = Store.validFamily(this).firstOrNull()
        if (primary != null) callNow(primary.phone) else callNow("112")
        finish()
    }

    private fun vibrate() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
        } catch (e: Exception) {
            // sin vibración
        }
    }

    override fun onDestroy() {
        cancelTimer()
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }
}
