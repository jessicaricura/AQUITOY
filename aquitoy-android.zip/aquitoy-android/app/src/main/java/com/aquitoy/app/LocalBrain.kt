package com.aquitoy.app

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Asistente sin internet y sin clave. Conversa con reglas: entiende ánimo, familia, comida, sueño,
 * recuerdos, juegos (chistes, refranes, adivinanzas, cuentos), órdenes (hora, avisos, abrir apps)
 * y va enlazando preguntas. No es una inteligencia artificial: para eso hace falta la clave de Claude.
 */
object LocalBrain {
    private val rnd = java.util.Random()
    private var pending = ""
    private var riddleIdx = -1
    private var wrong = 0
    private var lastGame = ""
    private var turns = 0
    private val recent = ArrayList<String>()

    private val words = mapOf(
        "una" to 1, "uno" to 1, "un" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6,
        "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "quince" to 15, "veinte" to 20, "treinta" to 30
    )

    // ---------------- Contenido ----------------
    private val jokes = listOf(
        "¿Qué hace una abeja en el gimnasio? Zum-ba.",
        "¿Cuál es el colmo de un electricista? Que su mujer se llame Luz y sus hijos le sigan la corriente.",
        "Doctor, doctor, me veo transparente. Pues no lo veo claro.",
        "¿Por qué los pájaros vuelan hacia el sur? Porque caminando tardarían mucho.",
        "¿Qué le dice un jardinero a otro? Disfrutemos mientras podamos.",
        "¿Qué le dice un huevo a una sartén? Me tienes frito.",
        "¿Cuál es el café más peligroso del mundo? El ex-preso.",
        "¿Qué le dice una iguana a su hermana gemela? Somos iguanitas."
    )

    private val proverbs = listOf(
        Pair("A quien madruga, Dios le ayuda.", "Quien se levanta pronto suele aprovechar mejor el día."),
        Pair("Más vale pájaro en mano que ciento volando.", "Es mejor lo seguro que lo que solo es una posibilidad."),
        Pair("No hay mal que por bien no venga.", "A veces de lo malo sale algo bueno."),
        Pair("Dime con quién andas y te diré quién eres.", "Las compañías dicen mucho de cada persona."),
        Pair("En casa del herrero, cuchillo de palo.", "A veces quien más sabe de algo es quien menos lo aplica en su propia casa."),
        Pair("Camarón que se duerme se lo lleva la corriente.", "Quien se descuida pierde oportunidades."),
        Pair("Al mal tiempo, buena cara.", "Hay que afrontar los problemas con ánimo."),
        Pair("Quien bien te quiere te hará llorar.", "Quien nos quiere de verdad nos dice la verdad aunque duela.")
    )

    // pregunta, patrón de respuesta (sin acentos), respuesta
    private val riddles = listOf(
        Triple("Tiene agujas pero no pincha, da la hora y no tiene boca. ¿Qué es?", "reloj", "El reloj"),
        Triple("Blanca por dentro, verde por fuera. Si quieres que te lo diga, espera.", "pera", "La pera"),
        Triple("Oro parece, plata no es. ¿Qué es?", "platano|banana", "El plátano"),
        Triple("Vuela sin alas, silba sin boca, azota sin manos y no lo ves. ¿Qué es?", "viento|aire", "El viento"),
        Triple("Tengo ciudades sin casas, ríos sin agua y montañas sin árboles. ¿Qué soy?", "mapa", "Un mapa"),
        Triple("Cuanto más se seca, más moja. ¿Qué es?", "toalla", "La toalla"),
        Triple("Tiene cabeza y dientes, pero no es persona ni muerde. Se usa mucho en la cocina.", "ajo", "El ajo")
    )

    private val facts = listOf(
        "Los pulpos tienen tres corazones.",
        "La miel bien guardada no se estropea nunca: se han encontrado tarros de miles de años que seguían buenos.",
        "El corazón late unas cien mil veces cada día.",
        "Madrid está a unos seiscientos cincuenta metros de altura, una de las capitales más altas de Europa.",
        "El Quijote se publicó por primera vez en mil seiscientos cinco.",
        "Las jirafas duermen muy poco, en ratitos cortos repartidos a lo largo del día.",
        "Reírse un rato ayuda a relajar los músculos y mejora el ánimo.",
        "Los gatos pasan durmiendo más de la mitad de su vida."
    )

    private val stories = listOf(
        "Te cuento la fábula de la liebre y la tortuga. Una liebre se burlaba de la lentitud de una tortuga, y la tortuga le propuso echar una carrera. La liebre salió corriendo, y como iba tan por delante se echó a dormir la siesta. La tortuga siguió despacio, sin parar, y llegó la primera. La moraleja es que la constancia vence a la prisa.",
        "Te cuento la fábula de la cigarra y la hormiga. Durante el verano la cigarra cantaba, mientras la hormiga trabajaba guardando comida. Cuando llegó el invierno, la cigarra pasó hambre y pidió ayuda. La hormiga le dio de comer, pero le recordó que hay que prepararse para los días difíciles."
    )

    private val memoryQuestions = listOf(
        "¿Cuál era tu comida favorita cuando eras pequeño o pequeña?",
        "¿Cómo era el sitio donde te criaste?",
        "¿Qué trabajo hiciste y qué era lo que más te gustaba de él?",
        "¿Cuál ha sido el mejor viaje que has hecho?",
        "¿Qué música te gustaba bailar de joven?",
        "¿Quién te enseñó a cocinar?",
        "¿Tienes alguna receta de familia que te guste mucho?",
        "¿Cómo conociste a tus mejores amistades?",
        "¿Cuál ha sido uno de los días más felices de tu vida?",
        "¿A qué jugabas de pequeño o pequeña?",
        "¿Hay alguna película que hayas visto muchas veces?",
        "¿Qué te gusta hacer cuando hace buen día?"
    )

    private val acks = listOf(
        "Qué interesante.", "Entiendo.", "Gracias por contármelo.", "Me gusta escucharte.",
        "Vaya, no lo sabía.", "Qué bien que me lo cuentes.", "Tiene mucho sentido.", "Cuánto me alegra que hablemos."
    )

    private val followups = listOf(
        "¿Y qué es lo que más recuerdas de eso?", "¿Y cómo te hizo sentir?", "¿Y qué pasó después?",
        "¿Quieres contarme algo más?", "¿Y con quién lo compartías?", "¿Y eso te sigue gustando hoy?",
        "¿Qué es lo mejor de todo eso?"
    )

    private val shortFallbacks = listOf(
        "Te escucho. Cuéntame un poco más.", "Dime, ¿y eso cómo te hace sentir?", "Vale, sigo aquí. ¿Qué más me cuentas?",
        "Entiendo. ¿Quieres que hablemos de otra cosa?"
    )

    private val topics: List<Pair<Regex, List<String>>> = listOf(
        Pair(Regex("\\b(cocin|receta|guiso|lentejas|paella|tortilla|postre|comida casera)"), listOf(
            "Cocinar es un arte. ¿Cuál es el plato que mejor te sale?",
            "Qué rico. ¿Quién te enseñó esa receta?",
            "Me encantaría oler esa cocina. ¿Lo preparas para tu familia?"
        )),
        Pair(Regex("\\b(perro|gato|mascota|pajaro|canario)"), listOf(
            "Los animales hacen muy buena compañía. ¿Cómo se llama?",
            "Qué cariño se les coge. ¿Qué es lo que más le gusta hacer?"
        )),
        Pair(Regex("\\b(jardin|plantas|flores|huerto|macetas|tomates)"), listOf(
            "Cuidar plantas da mucha paz. ¿Cuál es tu favorita?",
            "Qué bonito. ¿Cuál es la flor que más te gusta?"
        )),
        Pair(Regex("\\b(pueblo|de pequen|cuando era joven|de joven|antes se)"), listOf(
            "Los recuerdos de antes son un tesoro. ¿Qué es lo que más echas de menos de aquella época?",
            "Qué bonito recuerdo. ¿Cómo era un día normal entonces?"
        )),
        Pair(Regex("\\b(viaje|viaj|vacaciones|playa|montana)"), listOf(
            "Viajar es una maravilla. ¿Cuál es el lugar que más te ha gustado?",
            "Qué buena idea. ¿Con quién te gustaría ir?"
        )),
        Pair(Regex("\\b(television|tele|serie|pelicula|novela|programa)"), listOf(
            "Una buena película o serie hace compañía. ¿Cuál te gusta más?",
            "¿Y quién es tu actor o actriz favorita?"
        )),
        Pair(Regex("\\b(libro|leer|leyendo|lectura|periodico|crucigrama|sopa de letras)"), listOf(
            "Leer mantiene la mente despierta. ¿Qué te gusta leer?",
            "Qué buen pasatiempo. ¿Me recomiendas algo que te haya gustado?"
        )),
        Pair(Regex("\\b(musica|cancion|bailar|baile|copla|bolero|radio)"), listOf(
            "La música alegra el día. ¿Cuál es tu canción favorita?",
            "Bailar es muy sano. ¿Qué te gustaba bailar?"
        )),
        Pair(Regex("\\b(trabaj|jubilad|oficio|empresa|fabrica|colegio|maestr)"), listOf(
            "Se aprende mucho trabajando. ¿Qué es lo que más te gustaba?",
            "Qué trayectoria. ¿Cuál era lo mejor de tu día de trabajo?"
        )),
        Pair(Regex("\\b(futbol|partido|equipo|real madrid|barca|atletico|tenis)"), listOf(
            "Qué afición. ¿De qué equipo eres?",
            "Un partido anima cualquier tarde. ¿Lo ves con alguien?"
        )),
        Pair(Regex("\\b(misa|iglesia|rezar|rosario|parroquia)"), listOf(
            "Es bonito tener esa costumbre. ¿Vas con alguien a la iglesia?"
        )),
        Pair(Regex("\\b(tiempo libre|hobby|aficion|costura|tejer|punto|ganchillo|pintar|manualidades)"), listOf(
            "Qué buen entretenimiento. ¿Qué es lo último que has hecho?",
            "Las manos ocupadas dan alegría. ¿Cuánto tiempo llevas con esa afición?"
        )),
        Pair(Regex("\\b(vecin|amig|amiga|cafe con|quedar con)"), listOf(
            "Las buenas amistades son lo mejor. ¿Cada cuánto os veis?",
            "Qué suerte tener con quién charlar. ¿Qué os gusta hacer juntos?"
        ))
    )

    // ---------------- Utilidades ----------------
    private fun plain(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()

    private fun num(w: String): Int? = w.toIntOrNull() ?: words[w]

    private fun has(t: String, pattern: String): Boolean = Regex(pattern).containsMatchIn(t)

    private fun say(text: String) = ClaudeReply(text, emptyList())

    private fun act(text: String, name: String, input: JSONObject) = ClaudeReply(text, listOf(ClaudeAction(name, input)))

    private fun pick(list: List<String>): String {
        var s = list[rnd.nextInt(list.size)]
        var tries = 0
        while (recent.contains(s) && tries < 6) {
            s = list[rnd.nextInt(list.size)]
            tries += 1
        }
        recent.add(s)
        while (recent.size > 8) recent.removeAt(0)
        return s
    }

    private fun yes(t: String) = has(t, "\\b(si|claro|vale|venga|por supuesto|ok|dale|bueno|de acuerdo|otra|otro|quiero|me gustaria)\\b") && !no(t)
    private fun no(t: String) = has(t, "\\b(no|nada|ni|tampoco|paso|mal|nunca)\\b")

    fun reset() {
        pending = "feel"
        riddleIdx = -1
        wrong = 0
        lastGame = ""
        turns = 0
        recent.clear()
    }

    // ---------------- Juegos ----------------
    private fun serve(game: String): ClaudeReply {
        lastGame = game
        return when (game) {
            "chiste" -> {
                pending = "more"
                say(pick(jokes) + " ¿Quieres otro?")
            }
            "refran" -> {
                val p = proverbs[rnd.nextInt(proverbs.size)]
                pending = "more"
                say("Un refrán: " + p.first + " Significa: " + p.second + " ¿Quieres otro?")
            }
            "adivinanza" -> {
                riddleIdx = rnd.nextInt(riddles.size)
                wrong = 0
                pending = "riddle"
                say("Vamos con una adivinanza. " + riddles[riddleIdx].first)
            }
            "dato" -> {
                pending = "more"
                say("Un dato curioso: " + pick(facts) + " ¿Quieres otro?")
            }
            "cuento" -> {
                pending = "more"
                say(pick(stories) + " ¿Quieres que te cuente otro?")
            }
            else -> {
                pending = "open"
                say(pick(memoryQuestions))
            }
        }
    }

    private fun feeling(t: String): String = when {
        has(t, "\\bno (estoy|me siento|me encuentro|ando) (muy |nada |del todo )?(bien|contenta|contento|animad)") -> "bad"
        has(t, "\\b(me duele|dolor|mareo|mareada|mareado|enferm|fiebre|malita|malito)") -> "pain"
        has(t, "\\b(triste|sola|solo|deprimid|agobiad|nervios|preocupad|angustia|llorar|desanimad|fatal|fatal)\\b") -> "bad"
        has(t, "\\b(cansad|agotad|sin fuerzas|rendid)") -> "tired"
        has(t, "\\b(regular|asi asi|normal|tirando|vamos tirando|ni fu ni fa)\\b") -> "meh"
        has(t, "\\b(bien|genial|contenta|contento|feliz|estupend|fenomenal|de maravilla|muy bien|animad|perfect)") -> "good"
        has(t, "\\b(mal|peor|fatal)\\b") -> "bad"
        else -> ""
    }

    private fun feelingReply(f: String): ClaudeReply = when (f) {
        "good" -> {
            pending = ""
            say(pick(listOf(
                "Me alegra mucho oírlo. ¿Qué tienes pensado hacer hoy?",
                "Qué bien. Un buen día se disfruta más compartido. ¿Qué planes tienes?"
            )))
        }
        "bad" -> {
            pending = "open"
            say("Siento que no estés del todo bien. Estoy aquí para escucharte, sin prisa. ¿Quieres contarme qué te pasa?")
        }
        "tired" -> {
            pending = "sleep"
            say("Descansar es importante. ¿Has dormido bien esta noche?")
        }
        "meh" -> {
            pending = ""
            say("Hay días así. ¿Qué te vendría mejor: charlar un rato, un chiste o salir a dar un pequeño paseo?")
        }
        else -> {
            pending = ""
            say("Si te duele algo o no te encuentras bien, díselo hoy a tu médico o a tu familia. Si es fuerte, mantén pulsado el botón rojo de ayuda o llama al ciento doce. ¿Quieres que te ponga un aviso para acordarte?")
        }
    }

    private fun openApp(t: String): String? {
        val map = listOf(
            Pair("whatsapp|wasap|guasap", "whatsapp"),
            Pair("camara|hacer una foto|sacar una foto", "camara"),
            Pair("fotos|galeria|imagenes", "fotos"),
            Pair("calculadora|hacer una cuenta|cuentas", "calculadora"),
            Pair("youtube|videos|musica", "youtube"),
            Pair("mapa|maps|como llegar|ruta", "maps"),
            Pair("correo|email|gmail|hotmail|yahoo", "correo"),
            Pair("mensajes|sms", "mensajes"),
            Pair("notas|apuntes|apuntar", "notas"),
            Pair("contactos|agenda", "contactos"),
            Pair("buscar|google|internet", "buscar"),
            Pair("tienda de aplicaciones|play store|descargar", "playstore"),
            Pair("avisos|notificaciones", "avisos")
        )
        for (m in map) if (has(t, "\\b(" + m.first + ")")) return m.second
        return null
    }

    // ---------------- Respuesta principal ----------------
    fun reply(c: Context, heard: String): ClaudeReply {
        val t = plain(heard)
        val now = Calendar.getInstance()
        turns += 1
        learn(c, heard, t)

        if (has(t, "\\b(adios|hasta luego|hasta pronto|nada mas|terminar|dejalo|chao|buenas noches y)\\b")) {
            return ClaudeReply("Hasta pronto. Cuídate mucho.", listOf(ClaudeAction("fin_conversacion", JSONObject())))
        }

        // Urgencias: lo primero de todo
        if (has(t, "(dolor (de|en el) pecho|me duele el pecho|no puedo respirar|me falta el aire|me he caido|desmay|sangre|infarto|ictus|derrame|se me duerme la (cara|mano|pierna))")) {
            return say("Esto puede ser grave. Llama ahora mismo al ciento doce, o mantén pulsado el botón rojo de ayuda. No esperes.")
        }

        // Abrir aplicaciones
        val openVerb = has(t, "\\b(abre|abrir|abreme|entra en|ve a|quiero ver|ensename|pon|ponme|enciende|quiero usar|quiero hacer|quiero mirar|quiero llamar|llama a|llamar|llamame|quiero escribir|escribir)\\b")
        if (openVerb) {
            if (has(t, "(llama a|llamar|llamame|telefono)")) {
                return act("Claro, te abro las llamadas.", "abrir", JSONObject().put("que", "llamar"))
            }
            if (has(t, "\\balarma\\b") && parseTime(t, now) == null) {
                return act("Claro, te abro las alarmas.", "abrir", JSONObject().put("que", "alarma"))
            }
            if (has(t, "\\brecordatorios?\\b") && parseTime(t, now) == null) {
                return act("Claro, te abro los recordatorios.", "abrir", JSONObject().put("que", "recordatorios"))
            }
            val app = openApp(t)
            if (app != null && !has(t, "\\b(avisame|recuerdame)\\b")) {
                val name = when (app) {
                    "whatsapp" -> "WhatsApp"
                    "camara" -> "la cámara"
                    "fotos" -> "las fotos"
                    "calculadora" -> "la calculadora"
                    "youtube" -> "YouTube"
                    "maps" -> "Maps"
                    "correo" -> "el correo"
                    "mensajes" -> "los mensajes"
                    "notas" -> "las notas"
                    "contactos" -> "los contactos"
                    "buscar" -> "el buscador"
                    "playstore" -> "la tienda de aplicaciones"
                    else -> "los avisos"
                }
                return act("Claro, te abro $name.", "abrir", JSONObject().put("que", app))
            }
        }

        // Avisos, alarmas, recordatorios
        val wantsReminder = has(t, "\\b(avisame|avisarme|avisa|recuerdame|recordarme|recuerda|recordatorio|alarma|despiertame|pon(me)? un aviso)\\b")
        if (wantsReminder) {
            val time = parseTime(t, now)
            if (time == null) {
                pending = ""
                return say("Dime a qué hora. Por ejemplo: avísame a las cinco y media de tomar la pastilla.")
            }
            val tomorrow = heard.lowercase().contains("mañana") &&
                !Regex("(de|por|en) la mañana").containsMatchIn(heard.lowercase())
            val daily = has(t, "(todos los dias|cada dia|diari)")
            val input = JSONObject()
            input.put("hora", String.format("%02d:%02d", time.first, time.second))
            input.put("texto", reminderText(t))
            input.put("dia", if (tomorrow) "manana" else "hoy")
            input.put("cada_dia", daily)
            pending = ""
            return ClaudeReply("", listOf(ClaudeAction("crear_recordatorio", input)))
        }

        if (has(t, "\\b(que hora|la hora|hora es)\\b")) {
            return say("Son las " + spokenTime(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE)) + ".")
        }
        if (has(t, "\\b(que dia|fecha|dia es|a cuantos estamos|que dia de la semana)\\b")) {
            val d = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES")).format(Date())
            return say("Hoy es $d.")
        }
        if (has(t, "\\b(mis avisos|mis recordatorios|que avisos|que tengo pendiente|mis alarmas)\\b")) {
            val items = Store.reminders(c).filter { it.enabled }.sortedBy { it.triggerAt }
            if (items.isEmpty()) return say("No tienes ningún aviso pendiente.")
            val txt = items.take(4).joinToString(". ") { String.format("A las %02d:%02d, %s", it.hour, it.minute, it.text) }
            return say("Tienes $txt.")
        }

        // Respuestas a mi última pregunta
        when (pending) {
            "riddle" -> {
                if (riddleIdx >= 0) {
                    val r = riddles[riddleIdx]
                    if (has(t, "\\b(" + r.second + ")")) {
                        pending = "more"
                        lastGame = "adivinanza"
                        return say("¡Muy bien, lo has acertado! Era: " + r.third + ". ¿Quieres otra adivinanza?")
                    }
                    if (has(t, "(me rindo|no se|ni idea|dimelo|dime la respuesta|cual es|no lo se)")) {
                        pending = "more"
                        lastGame = "adivinanza"
                        return say("No pasa nada. Era: " + r.third + ". ¿Probamos con otra?")
                    }
                    if (!has(t, "\\b(chiste|refran|cuento|dato|basta|otra cosa|dejalo|cambia)\\b")) {
                        wrong += 1
                        if (wrong >= 2) {
                            pending = "more"
                            lastGame = "adivinanza"
                            return say("Casi. La respuesta era: " + r.third + ". ¿Quieres otra?")
                        }
                        return say("Mmm, no es eso. Piénsalo otro poquito, o dime me rindo.")
                    }
                }
                pending = ""
            }
            "feel" -> {
                val f = feeling(t)
                if (f.isNotEmpty()) return feelingReply(f)
                pending = ""
            }
            "sleep" -> {
                if (yes(t)) {
                    pending = "food"
                    return say("Qué bien, dormir bien lo cambia todo. ¿Y has desayunado ya?")
                }
                if (no(t)) {
                    pending = ""
                    return say("Vaya, lo siento. Una infusión caliente por la noche y evitar el café por la tarde pueden ayudar. Si sigue pasando, coméntaselo a tu médico. ¿Quieres que te ponga un aviso para acostarte a una hora fija?")
                }
                pending = ""
            }
            "food" -> {
                if (yes(t)) {
                    pending = "open"
                    return say("Muy bien, comer a sus horas es importante. ¿Qué has tomado?")
                }
                if (no(t)) {
                    pending = ""
                    return say("Procura tomar algo ligero y beber agua. ¿Quieres que te ponga un aviso para comer?")
                }
                pending = ""
            }
            "call2" -> {
                pending = ""
                if (yes(t)) return act("Muy bien, te abro el buscador.", "abrir", JSONObject().put("que", "buscar"))
                if (no(t)) return say("Vale, como prefieras.")
            }
            "call" -> {
                if (yes(t)) {
                    pending = ""
                    return act("Muy bien, te abro las llamadas.", "abrir", JSONObject().put("que", "llamar"))
                }
                pending = ""
                if (no(t)) return say("Vale, cuando quieras me lo dices.")
            }
            "more" -> {
                if (yes(t) && lastGame.isNotEmpty()) return serve(lastGame)
                if (no(t)) {
                    pending = ""
                    return say("Vale. ¿Quieres que hablemos de otra cosa?")
                }
                pending = ""
            }
            "open" -> pending = ""
        }

        // Peticiones concretas
        if (has(t, "\\b(chiste|gracioso|hazme reir|hazme gracia)")) return serve("chiste")
        if (has(t, "\\b(refran|dicho popular)")) return serve("refran")
        if (has(t, "\\b(adivinanza|acertijo|jugar|juego|juguemos)")) return serve("adivinanza")
        if (has(t, "\\b(dato curioso|curiosidad|cuentame algo|algo interesante|dime algo|sabes algo)")) return serve("dato")
        if (has(t, "\\b(cuento|cuentame una historia|una historia|fabula)")) return serve("cuento")
        if (has(t, "\\b(aburrid|aburro|no tengo nada que hacer|me aburr)")) {
            val games = listOf("chiste", "adivinanza", "dato", "refran", "recuerdo")
            val g = games[rnd.nextInt(games.size)]
            val first = serve(g)
            return say("Vamos a pasar un buen rato. " + first.text)
        }

        if (has(t, "\\b(que sabes de mi|que recuerdas de mi|sabes algo de mi)")) {
            val mem = Store.memory(c).takeLast(4)
            return if (mem.isEmpty()) say("Todavía no me has contado mucho. Cuéntame cosas y las iré recordando.")
            else say("Recuerdo que " + mem.joinToString(". ") + ".")
        }
        if (has(t, "\\b(como te llamas|quien eres|que eres)\\b")) {
            return say("Me llamo AQUITOY y soy tu compañía de voz. Puedo charlar contigo, ponerte avisos y abrirte las aplicaciones.")
        }
        if (has(t, "(que puedes hacer|que sabes hacer|para que sirves|como funcionas|ayudame|que haces)")) {
            return say("Puedo charlar contigo, decirte la hora, ponerte avisos y alarmas, contarte chistes, refranes, cuentos y adivinanzas, y abrir WhatsApp, la cámara o las llamadas. Pídemelo como quieras.")
        }
        if (has(t, "\\b(gracias|muchas gracias|te lo agradezco)\\b")) {
            return say(pick(listOf("De nada. Aquí estoy para lo que necesites.", "Para eso estoy. ¿Necesitas algo más?")))
        }
        if (has(t, "\\b(te quiero|eres muy|que lista|que maja|eres un encanto|eres genial|me caes bien|eres buena)")) {
            return say("Qué amable eres, me haces sentir muy bien. A mí también me gusta mucho charlar contigo.")
        }
        if (has(t, "\\b(tonta|inutil|no sirves|estupida|eres mala)\\b")) {
            return say("Perdona si no te he entendido bien. Dímelo de otra manera y lo intento de nuevo.")
        }
        if (has(t, "(que tiempo hace|va a llover|hara frio|hara calor|el tiempo de (hoy|manana)|prevision|temperatura)")) {
            return say("Sin internet no puedo mirar el tiempo. Puedes asomarte a la ventana, o abrir el buscador y escribir el tiempo de tu pueblo. ¿Quieres que te lo abra?").also { pending = "call2" }
        }
        if (has(t, "\\b(noticias|telediario|que ha pasado hoy|periodico de hoy)\\b")) {
            return say("Sin internet no puedo darte las noticias de hoy. Con la clave de Claude y conexión sí podría contarte más. Mientras, puedes escuchar la radio o la televisión.")
        }
        if (has(t, "\\b(pon musica|poner musica|quiero musica|escuchar musica|quiero escuchar)")) {
            return act("Claro, te abro YouTube para que busques tu música.", "abrir", JSONObject().put("que", "youtube"))
        }

        // Estados de ánimo y temas cotidianos
        val f = feeling(t)
        if (f.isNotEmpty() && (f == "pain" || has(t, "\\b(me siento|estoy|ando|me encuentro|hoy)\\b"))) {
            return feelingReply(f)
        }
        if (has(t, "(estoy sola|estoy solo|me siento sola|me siento solo|echo de menos|nadie me llama|nadie me visita)")) {
            pending = "call"
            return say("Siento que te sientas así. No estás sola ni solo, estoy aquí contigo. Y seguro que a tu familia le encantaría oírte. ¿Quieres que abra las llamadas para saludarles?")
        }
        val fam = Regex("\\bmi (hij[oa]|niet[oa]|marido|espos[oa]|mujer|herman[oa]|madre|padre|nuera|yerno|sobrin[oa]|vecin[oa]|amig[oa])\\b").find(t)
        if (fam != null) {
            val rel = fam.groupValues[1]
            pending = "call"
            return say(pick(listOf(
                "Qué bien que me hables de tu $rel. ¿Cómo está? ¿Hace mucho que no habláis? Si quieres, abro las llamadas.",
                "Tu $rel debe de ser muy importante para ti. ¿Qué es lo que más te gusta de esa relación? ¿Quieres llamarle ahora?"
            )))
        }
        if (has(t, "\\b(dormi|dormir|sueno|insomnio|descans|desvel)")) {
            pending = "sleep"
            return say("El sueño es clave para encontrarse bien. ¿Has dormido bien esta noche?")
        }
        if (has(t, "\\b(comi|comer|desayun|almuerz|cena|merienda|hambre)")) {
            pending = "food"
            return say("Comer bien es importante. ¿Has comido ya hoy como te gusta?")
        }
        if (has(t, "\\b(paseo|pasear|caminar|gimnasia|ejercicio|andar)")) {
            return say(pick(listOf(
                "Pasear es buenísimo para el ánimo y las piernas. ¿Sueles salir a andar por tu barrio?",
                "Un paseo corto cada día sienta de maravilla. ¿Quieres que te ponga un aviso para salir a caminar?"
            )))
        }
        if (has(t, "\\b(medicin|pastilla|tension|azucar|medico|doctor|hospital|cita)")) {
            return say("Cuidar la salud es lo primero. Si quieres, te pongo un aviso para tus medicinas o tu cita. Dime la hora, por ejemplo: avísame a las nueve de tomar la pastilla.")
        }
        if (has(t, "^(si|no|vale|ya|ok|bueno|bien|mal|nada|nose|no se)$")) {
            return say("Entiendo. ¿Quieres contarme algo más, o prefieres que te cuente un chiste o te proponga una adivinanza?")
        }
        for (topic in topics) {
            if (topic.first.containsMatchIn(t)) return say(pick(topic.second))
        }
        if (has(t, "^(hola|buenos dias|buenas tardes|buenas noches|que tal|buenas)")) {
            pending = "feel"
            return say("Hola. ¿Cómo te encuentras hoy?")
        }

        // Conversación general: reconoce lo dicho y sigue preguntando
        val count = t.split(" ").filter { it.isNotBlank() }.size
        var out = if (count >= 8) pick(acks) + " " + pick(followups) else pick(shortFallbacks)
        if (turns % 5 == 0) out += " Si quieres, también puedo contarte un chiste, un refrán o proponerte una adivinanza."
        pending = ""
        return say(out)
    }

    /** Aprende datos sencillos de lo que dice la persona y los guarda en la memoria. */
    private fun learn(c: Context, heard: String, t: String) {
        try {
            Regex("(?i)\\b(?:me llamo|mi nombre es)\\s+(\\p{L}+)").find(heard)?.let {
                val n = it.groupValues[1]
                if (Store.name(c).isBlank()) Store.setName(c, n.replaceFirstChar { ch -> ch.uppercase() })
            }
            Regex("(?i)\\bmi (hij[oa]|niet[oa]|marido|espos[oa]|mujer|herman[oa]|madre|padre) se llama (\\p{L}+)").find(heard)?.let {
                Store.remember(c, "Su " + it.groupValues[1].lowercase() + " se llama " + it.groupValues[2])
            }
            Regex("\\bme gusta(?:n)? (?:mucho )?(?:el |la |los |las )?([a-z ]{3,30})").find(t)?.let {
                Store.remember(c, "Le gusta " + it.groupValues[1].trim())
            }
        } catch (e: Exception) {
            // sin aprender
        }
    }

    private fun spokenTime(h: Int, m: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        val part = if (h < 6) "de la madrugada" else if (h < 13) "de la mañana" else if (h < 20) "de la tarde" else "de la noche"
        val minutes = if (m == 0) "en punto" else "y $m"
        return "$h12 $minutes $part"
    }

    /** Devuelve (hora, minuto) de lo que se ha dicho, o null si no se entiende. */
    private fun parseTime(t: String, now: Calendar): Pair<Int, Int>? {
        // "en media hora", "en una hora", "en 10 minutos"
        if (Regex("\\ben media hora\\b").containsMatchIn(t)) return plusMinutes(now, 30)
        Regex("\\ben (\\w+) (minutos?|horas?)\\b").find(t)?.let {
            val n = num(it.groupValues[1])
            if (n != null) return plusMinutes(now, if (it.groupValues[2].startsWith("hora")) n * 60 else n)
        }
        var h: Int? = null
        var m = 0
        Regex("\\b(\\d{1,2})[:.](\\d{2})\\b").find(t)?.let {
            h = it.groupValues[1].toInt()
            m = it.groupValues[2].toInt()
        }
        if (h == null) {
            val r = Regex("\\ba las? (\\w+)(?: y (media|cuarto|\\w+)| menos (cuarto|\\w+)| en punto)?").find(t)
            if (r != null) {
                val base = num(r.groupValues[1])
                if (base != null) {
                    h = base
                    val plus = r.groupValues[2]
                    val minus = r.groupValues[3]
                    if (plus.isNotEmpty()) {
                        m = when (plus) {
                            "media" -> 30
                            "cuarto" -> 15
                            else -> num(plus) ?: 0
                        }
                    } else if (minus.isNotEmpty()) {
                        val less = if (minus == "cuarto") 15 else (num(minus) ?: 0)
                        h = base - 1
                        m = 60 - less
                    }
                }
            }
        }
        val hour = h ?: return null
        var hh = hour
        if (Regex("\\b(de la tarde|por la tarde|de la noche|por la noche)\\b").containsMatchIn(t) && hh in 1..11) hh += 12
        if (Regex("\\b(de la noche)\\b").containsMatchIn(t) && hh == 12) hh = 0
        if (hh < 0 || hh > 23 || m < 0 || m > 59) return null
        return Pair(hh, m)
    }

    private fun plusMinutes(now: Calendar, n: Int): Pair<Int, Int> {
        val c = now.clone() as Calendar
        c.add(Calendar.MINUTE, n)
        return Pair(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    private fun reminderText(t: String): String {
        var s = t
        s = s.replace(Regex("\\ben (media hora|\\w+ (minutos?|horas?))\\b"), " ")
        s = s.replace(Regex("\\ba las? \\w+( y (media|cuarto|\\w+)| menos (cuarto|\\w+)| en punto)?"), " ")
        s = s.replace(Regex("\\b\\d{1,2}[:.]\\d{2}\\b"), " ")
        s = s.replace(Regex("\\b(de la|por la) (manana|tarde|noche)\\b"), " ")
        s = s.replace(Regex("\\b(avisame|avisarme|avisa|recuerdame|recordarme|recuerda|recordatorio|alarma|despiertame|ponme|pon|un|una|aviso|manana|hoy|todos los dias|cada dia)\\b"), " ")
        s = s.replace(Regex("\\s+"), " ").trim()
        s = s.replace(Regex("^(para|que|de|a)\\s+"), "").trim()
        return if (s.isBlank()) "Aviso" else s.take(80)
    }
}
