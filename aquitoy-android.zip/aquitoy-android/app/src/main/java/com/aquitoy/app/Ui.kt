package com.aquitoy.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Pal {
    var BG: Int = Color.parseColor("#EEF2F7")
    var font: Float = 1f
    var simple: Boolean = false
    var square: Boolean = false
    val INK: Int = Color.parseColor("#12202E")
    val MUTED: Int = Color.parseColor("#3A4A5C")
    val BLUE: Int = Color.parseColor("#1456B8")
    val RED: Int = Color.parseColor("#B3261E")
    val GREEN: Int = Color.parseColor("#1B6E3C")
    val AMBER: Int = Color.parseColor("#A24A00")
    val LINE: Int = Color.parseColor("#C5D0DD")
    val WHITE: Int = Color.WHITE
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun shape(color: Int, radiusPx: Float, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.RECTANGLE
    g.setColor(color)
    g.cornerRadius = radiusPx
    if (strokePx > 0) g.setStroke(strokePx, strokeColor)
    return g
}

fun ripple(base: GradientDrawable): RippleDrawable =
    RippleDrawable(ColorStateList.valueOf(0x33000000), base, null)

fun Context.label(
    s: String,
    sp: Float = 20f,
    color: Int = Pal.INK,
    bold: Boolean = false,
    center: Boolean = false
): TextView {
    val t = TextView(this)
    t.text = s
    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * Pal.font)
    t.setTextColor(color)
    if (bold) t.typeface = Typeface.DEFAULT_BOLD
    if (center) t.gravity = Gravity.CENTER
    return t
}

fun Context.bigButton(
    text: String,
    bg: Int,
    fg: Int = Color.WHITE,
    strokeColor: Int = 0,
    onClick: () -> Unit
): Button {
    val b = Button(this)
    b.text = text
    b.setAllCaps(false)
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f * Pal.font)
    b.setTextColor(fg)
    b.typeface = Typeface.DEFAULT_BOLD
    b.minHeight = dp(72)
    b.minimumHeight = dp(72)
    b.stateListAnimator = null
    val strokePx = if (strokeColor != 0) dp(3) else 0
    b.background = ripple(shape(bg, dp(22).toFloat(), strokeColor, strokePx))
    b.setPadding(dp(16), dp(8), dp(16), dp(8))
    b.setOnClickListener { onClick() }
    return b
}

fun Context.smallButton(text: String, bg: Int, fg: Int, onClick: () -> Unit): Button {
    val b = Button(this)
    b.text = text
    b.setAllCaps(false)
    b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * Pal.font)
    b.setTextColor(fg)
    b.typeface = Typeface.DEFAULT_BOLD
    b.minHeight = dp(52)
    b.minimumHeight = dp(52)
    b.stateListAnimator = null
    b.background = ripple(shape(bg, dp(16).toFloat(), Pal.LINE, dp(2)))
    b.setPadding(dp(14), dp(4), dp(14), dp(4))
    b.setOnClickListener { onClick() }
    return b
}

fun Context.input(hint: String, initial: String = "", type: Int = InputType.TYPE_CLASS_TEXT): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setText(initial)
    e.inputType = type
    e.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f * Pal.font)
    e.setTextColor(Pal.INK)
    e.setHintTextColor(Color.parseColor("#6B7B8C"))
    e.setPadding(dp(14), dp(10), dp(14), dp(10))
    e.minHeight = dp(56)
    e.background = shape(Color.WHITE, dp(16).toFloat(), Pal.LINE, dp(3))
    return e
}

fun Context.card(): LinearLayout {
    val l = LinearLayout(this)
    l.orientation = LinearLayout.VERTICAL
    l.setPadding(dp(16), dp(14), dp(16), dp(14))
    l.background = shape(Color.WHITE, dp(20).toFloat(), Pal.LINE, dp(2))
    return l
}

fun Context.icon(res: Int, sizeDp: Int, tint: Int = Color.WHITE): ImageView {
    val v = ImageView(this)
    v.setImageResource(res)
    v.setColorFilter(tint)
    v.layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    return v
}

/** Añade una vista a un LinearLayout vertical ocupando todo el ancho. */
fun LinearLayout.addV(v: View, topDp: Int = 0, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) {
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h, weight)
    lp.topMargin = context.dp(topDp)
    addView(v, lp)
}

/** Añade una vista a una fila horizontal repartiendo el ancho por igual. */
fun LinearLayout.addH(v: View, leftDp: Int = 0) {
    val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    lp.leftMargin = context.dp(leftDp)
    addView(v, lp)
}

/** Barra superior grande con la hora y la batería. */
class TopBar(ctx: Context) : LinearLayout(ctx) {
    private val clock: TextView = ctx.label("--:--", 30f, Pal.INK, true)
    private val batt: TextView = ctx.label("", 20f, Pal.INK, true)
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            update()
            handler.postDelayed(this, 10000)
        }
    }

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(ctx.dp(20), ctx.dp(10), ctx.dp(20), ctx.dp(6))
        clock.maxLines = 1
        clock.setSingleLine(true)
        addView(clock, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        batt.maxLines = 1
        batt.setSingleLine(true)
        batt.gravity = Gravity.END
        addView(batt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ticker.run()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(ticker)
    }

    private fun update() {
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
        val i: Intent? = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (i == null) {
            batt.text = ""
            return
        }
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        if (level < 0 || scale <= 0) {
            batt.text = ""
            return
        }
        val pct = level * 100 / scale
        batt.text = (if (charging) "Cargando " else "Batería ") + pct + "%"
        batt.setTextColor(if (pct <= 20 && !charging) Pal.RED else Pal.INK)
    }
}

/** Pantalla base: sin barra del sistema, con nuestra hora y batería. */
open class BaseActivity : Activity() {
    protected lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        Look.apply(this)
        applyBrightness()
    }

    /** Aplica el brillo elegido a esta pantalla (-1 = el del sistema). */
    protected fun applyBrightness() {
        try {
            val b = Look.brightness(this)
            val lp = window.attributes
            lp.screenBrightness = if (b < 0) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else b / 100f
            window.attributes = lp
        } catch (e: Exception) {
            // sin cambio de brillo
        }
    }

    /** Crea la pantalla con título y botón de volver; devuelve el contenedor donde añadir cosas. */
    protected fun makeScreen(title: String, back: Boolean = true): LinearLayout {
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Pal.BG)
        root.addV(TopBar(this))

        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(20), dp(4), dp(20), dp(8))
        if (back) {
            val b = ImageButton(this)
            b.setImageResource(R.drawable.ic_back)
            b.setColorFilter(Pal.INK)
            b.contentDescription = "Volver"
            b.background = shape(Color.WHITE, dp(30).toFloat(), Pal.INK, dp(3))
            b.setOnClickListener { finish() }
            header.addView(b, LinearLayout.LayoutParams(dp(60), dp(60)))
        }
        val t = label(title, 30f, Pal.INK, true)
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = if (back) dp(14) else 0
        header.addView(t, tlp)
        root.addV(header)

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(20), dp(4), dp(20), dp(24))
        scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addV(scroll, 0, 0, 1f)
        setContentView(root)
        return content
    }
}
