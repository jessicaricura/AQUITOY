package com.aquitoy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager

/** Salta a la hora del aviso: arranca el servicio que suena y habla, y abre la pantalla de aviso. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val r = Store.reminder(context, id) ?: return

        // Programamos ya el siguiente si es diario; si no, se apaga.
        try {
            if (r.daily) {
                val next = r.copy(triggerAt = Scheduler.nextTrigger(r.hour, r.minute, true))
                Store.upsertReminder(context, next)
                Scheduler.schedule(context, next)
            } else {
                Store.upsertReminder(context, r.copy(enabled = false))
            }
        } catch (e: Exception) {
            ErrorLog.save(context, e)
        }

        var started = false
        try {
            AlarmService.start(context, r.text, r.alarm, r.hour, r.minute)
            started = true
        } catch (e: Exception) {
            ErrorLog.save(context, e)
        }
        if (!started) postFallbackNotification(context, r, id)

        try {
            val ring = Intent(context, RingActivity::class.java)
            ring.putExtra("text", r.text)
            ring.putExtra("alarm", r.alarm)
            ring.putExtra("hour", r.hour)
            ring.putExtra("minute", r.minute)
            ring.putExtra("viaService", started)
            ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            context.startActivity(ring)
        } catch (e: Exception) {
            // Si el sistema no deja abrir la pantalla, queda la notificación a pantalla completa.
        }
    }

    /** Plan B: notificación normal con sonido, por si no se pudo arrancar el servicio. */
    private fun postFallbackNotification(context: Context, r: Reminder, id: Long) {
        try {
            val ring = Intent(context, RingActivity::class.java)
            ring.putExtra("text", r.text)
            ring.putExtra("alarm", r.alarm)
            ring.putExtra("hour", r.hour)
            ring.putExtra("minute", r.minute)
            ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            val code = (id % 1000000007L).toInt()
            val full = PendingIntent.getActivity(context, code, ring, flags)

            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL, "Avisos y alarmas", NotificationManager.IMPORTANCE_HIGH)
            channel.enableVibration(true)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
            channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(channel)

            val n = Notification.Builder(context, CHANNEL)
                .setSmallIcon(R.drawable.ic_bell)
                .setContentTitle(if (r.alarm) "Alarma" else "Recordatorio")
                .setContentText(r.text)
                .setCategory(Notification.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .build()
            nm.notify(code, n)
        } catch (e: Exception) {
            ErrorLog.save(context, e)
        }
    }

    companion object {
        const val CHANNEL = "aquitoy_avisos"
    }
}
