package com.aquitoy.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** Aspecto de la app que elige el usuario: fondo, letra, brillo, diseño y orden de botones. */
object Look {
    val backgrounds: List<Pair<String, String>> = listOf(
        Pair("Gris suave", "#EEF2F7"),
        Pair("Blanco", "#FFFFFF"),
        Pair("Crema", "#FFF6E5"),
        Pair("Azul claro", "#E3F0FF"),
        Pair("Verde claro", "#E5F5E8"),
        Pair("Rosa claro", "#FDE9EF")
    )
    val fontNames: List<String> = listOf("Pequeña", "Normal", "Grande", "Muy grande")
    private val fontScales = floatArrayOf(0.9f, 1f, 1.15f, 1.3f)

    private fun p(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("aquitoy", Context.MODE_PRIVATE)

    /** Carga las preferencias en los valores que usan todas las pantallas. */
    fun apply(c: Context) {
        Pal.BG = Color.parseColor(backgrounds[bgIndex(c)].second)
        Pal.font = fontScales[fontIndex(c)]
        Pal.simple = simple(c)
        Pal.square = square(c)
    }

    /** Número que cambia cada vez que se toca un ajuste; sirve para redibujar el inicio. */
    fun stamp(c: Context): Int = p(c).getInt("lookStamp", 0)
    private fun touch(c: Context) {
        p(c).edit().putInt("lookStamp", stamp(c) + 1).apply()
    }

    fun bgIndex(c: Context): Int = p(c).getInt("lookBg", 0).coerceIn(0, backgrounds.size - 1)
    fun setBgIndex(c: Context, v: Int) { p(c).edit().putInt("lookBg", v).apply(); touch(c) }

    fun fontIndex(c: Context): Int = p(c).getInt("lookFont", 1).coerceIn(0, fontScales.size - 1)
    fun setFontIndex(c: Context, v: Int) { p(c).edit().putInt("lookFont", v).apply(); touch(c) }

    /** 1 o 2 botones por fila. */
    fun columns(c: Context): Int = if (p(c).getInt("lookCols", 2) == 1) 1 else 2
    fun setColumns(c: Context, v: Int) { p(c).edit().putInt("lookCols", v).apply(); touch(c) }

    /** true = todos los botones del mismo color. */
    fun simple(c: Context): Boolean = p(c).getBoolean("lookSimple", false)
    fun setSimple(c: Context, v: Boolean) { p(c).edit().putBoolean("lookSimple", v).apply(); touch(c) }

    /** true = botones con esquinas cuadradas. */
    fun square(c: Context): Boolean = p(c).getBoolean("lookSquare", false)
    fun setSquare(c: Context, v: Boolean) { p(c).edit().putBoolean("lookSquare", v).apply(); touch(c) }

    /** 10..100, o -1 para usar el brillo del sistema. */
    fun brightness(c: Context): Int = p(c).getInt("lookBright", -1)
    fun setBrightness(c: Context, v: Int) { p(c).edit().putInt("lookBright", v).apply(); touch(c) }

    /** Al actualizar la app, los botones nuevos aparecen también a quien ya tenía la app configurada. */
    fun migrate(c: Context) {
        if (p(c).getBoolean("lookMigrated", false)) return
        p(c).edit().putBoolean("lookMigrated", true).apply()
        if (p(c).getString("apps", null) != null) {
            Store.setVisibleApps(c, Store.visibleApps(c) + listOf("personalizar", "playstore", "youtube", "calculadora", "maps"))
        }
    }

    // ---- Orden de los botones ----
    fun order(c: Context): List<String> =
        (p(c).getString("lookOrder", "") ?: "").split(",").filter { it.isNotBlank() }

    fun setOrder(c: Context, ids: List<String>) {
        p(c).edit().putString("lookOrder", ids.joinToString(",")).apply()
        touch(c)
    }

    // ---- Apps del móvil añadidas como botón (formato "paquete|nombre", una por línea) ----
    fun custom(c: Context): List<Pair<String, String>> {
        val s = p(c).getString("lookCustom", "") ?: ""
        val out = ArrayList<Pair<String, String>>()
        for (line in s.split("\n")) {
            val i = line.indexOf('|')
            if (i > 0) out.add(Pair(line.substring(0, i), line.substring(i + 1)))
        }
        return out
    }

    private fun saveCustom(c: Context, list: List<Pair<String, String>>) {
        p(c).edit().putString("lookCustom", list.joinToString("\n") { it.first + "|" + it.second.replace("\n", " ") }).apply()
        touch(c)
    }

    fun addCustom(c: Context, pkg: String, name: String) {
        val list = custom(c).filter { it.first != pkg } + Pair(pkg, name)
        saveCustom(c, list)
        Store.setVisibleApps(c, Store.visibleApps(c) + ("app:" + pkg))
    }

    fun removeCustom(c: Context, pkg: String) {
        saveCustom(c, custom(c).filter { it.first != pkg })
        Store.setVisibleApps(c, Store.visibleApps(c) - ("app:" + pkg))
        setOrder(c, order(c).filter { it != "app:$pkg" })
    }
}
