package com.aquitoy.app

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout

/** Pantalla grande que suena y habla cuando llega la hora de un aviso o una alarma. */
class RingActivity : BaseActivity() {
    private var speaker: Speaker? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var spokenTimes = 0
    private var text = ""
    private var isAlarm = false
    private var stopped = false

    private val repeat = object : Runnable {
        override fun run() {
            if (stopped) return
            if (spokenTimes >= 8) return
            spokenTimes += 1
            val phrase = if (isAlarm) "Alarma. $text" else "Recordatorio. $text"
            speaker?.speak(phrase, true, null)
            handler.postDelayed(this, 25000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        text = intent.getStringExtra("text") ?: "Es la hora"
        isAlarm = intent.getBooleanExtra("alarm", false)
        val hour = intent.getIntExtra("hour", 0)
        val minute = intent.getIntExtra("minute", 0)

        val c = makeScreen(if (isAlarm) "Alarma" else "Recordatorio", false)
        root.setBackgroundColor(Color.parseColor("#FFF4E5"))
        c.gravity = Gravity.CENTER_HORIZONTAL

        c.addV(icon(R.drawable.ic_bell, 96, Pal.AMBER), 24, dp(96))
        c.addV(label(String.format("%02d:%02d", hour, minute), 56f, Pal.INK, true, true), 8)
        c.addV(label(text, 32f, Pal.INK, true, true), 12)
        c.addV(bigButton("Ya lo he hecho", Pal.BLUE) { stopAll(); finish() }, 40)
        c.addV(bigButton("Avísame en 10 minutos", Color.WHITE, Pal.INK, Pal.INK) { snooze() }, 14)

        // Cancelamos la notificación para que no suene dos veces.
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancelAll()

        speaker = Speaker(this)
        if (isAlarm) startAlarmSound()
        handler.postDelayed(repeat, if (isAlarm) 2500 else 400)
    }

    private fun startAlarmSound() {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            // Sin sonido de alarma: queda la voz.
        }
    }

    private fun snooze() {
        val cal = java.util.Calendar.getInstance()
        cal.add(java.util.Calendar.MINUTE, 10)
        Scheduler.create(
            this, cal.get(java.util.Calendar.HOUR_OF_DAY), cal.get(java.util.Calendar.MINUTE),
            text, false, isAlarm
        )
        toast("Te aviso en 10 minutos")
        stopAll()
        finish()
    }

    private fun stopAll() {
        stopped = true
        handler.removeCallbacks(repeat)
        speaker?.shutdown()
        speaker = null
        try {
            player?.stop()
            player?.release()
        } catch (e: Exception) {
            // nada
        }
        player = null
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Evitamos cerrar el aviso sin querer.
    }
}
