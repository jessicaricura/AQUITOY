package com.aquitoy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build

/** Salta a la hora del aviso: abre la pantalla de aviso, incluso con el móvil bloqueado. */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra("id", -1L)
        val r = Store.reminder(context, id) ?: return

        // Programamos ya el siguiente si es diario; si no, se apaga.
        if (r.daily) {
            val next = r.copy(triggerAt = Scheduler.nextTrigger(r.hour, r.minute, true))
            Store.upsertReminder(context, next)
            Scheduler.schedule(context, next)
        } else {
            Store.upsertReminder(context, r.copy(enabled = false))
        }

        val ring = Intent(context, RingActivity::class.java)
        ring.putExtra("text", r.text)
        ring.putExtra("alarm", r.alarm)
        ring.putExtra("hour", r.hour)
        ring.putExtra("minute", r.minute)
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)

        val flags = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val code = (id % 1000000007L).toInt()
        val full = PendingIntent.getActivity(context, code, ring, flags)

        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = NotificationChannel(CHANNEL, "Avisos y alarmas", NotificationManager.IMPORTANCE_HIGH)
        channel.description = "Recordatorios y alarmas de AQUITOY"
        channel.enableVibration(true)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        channel.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), attrs)
        channel.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(channel)

        val title = if (r.alarm) "Alarma" else "Recordatorio"
        val n = Notification.Builder(context, CHANNEL)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(title)
            .setContentText(r.text)
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setAutoCancel(true)
            .setContentIntent(full)
            .setFullScreenIntent(full, true)
            .build()
        nm.notify(code, n)

        // Si el sistema nos deja, abrimos la pantalla directamente.
        try {
            context.startActivity(ring)
        } catch (e: Exception) {
            // Se queda la notificación a pantalla completa.
        }
    }

    companion object {
        const val CHANNEL = "aquitoy_avisos"
    }
}
