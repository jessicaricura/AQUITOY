package com.aquitoy.app

import android.app.Application
import android.content.Context

/** Guarda el último fallo de la app para poder verlo en Ajustes y enviarlo a quien la arregla. */
object ErrorLog {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("aquitoy_err", Context.MODE_PRIVATE)

    fun last(c: Context): String = p(c).getString("last", "") ?: ""

    fun clear(c: Context) {
        p(c).edit().remove("last").apply()
    }

    fun save(c: Context, t: Throwable) {
        try {
            val sw = java.io.StringWriter()
            t.printStackTrace(java.io.PrintWriter(sw))
            val text = sw.toString().lines().take(14).joinToString("\n")
            p(c).edit().putString("last", text).commit()
        } catch (e: Exception) {
            // no hacemos nada más
        }
    }
}

class AquiApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            ErrorLog.save(this, error)
            if (previous != null) previous.uncaughtException(thread, error)
        }
    }
}
