package com.aquitoy.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.util.TypedValue

/** Personalizar: fondo, letra, brillo, diseño, y qué botones hay y en qué orden. */
class AppearanceActivity : BaseActivity() {
    private lateinit var rowsBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Personalizar")
        c.addV(label("Los cambios se ven al volver al inicio.", 20f, Pal.MUTED))

        // ---- Fondo ----
        c.addV(label("Color de fondo", 24f, Pal.INK, true), 20)
        val bgRow = LinearLayout(this)
        bgRow.orientation = LinearLayout.HORIZONTAL
        val current = Look.bgIndex(this)
        val swatches = ArrayList<View>()
        for ((i, bg) in Look.backgrounds.withIndex()) {
            val sw = View(this)
            sw.contentDescription = bg.first
            sw.background = shape(Color.parseColor(bg.second), dp(24).toFloat(), if (i == current) Pal.BLUE else Pal.LINE, if (i == current) dp(5) else dp(2))
            sw.setOnClickListener {
                Look.setBgIndex(this, i)
                Look.apply(this)
                root.setBackgroundColor(Pal.BG)
                for ((j, v) in swatches.withIndex()) {
                    v.background = shape(Color.parseColor(Look.backgrounds[j].second), dp(24).toFloat(), if (j == i) Pal.BLUE else Pal.LINE, if (j == i) dp(5) else dp(2))
                }
            }
            swatches.add(sw)
            val lp = LinearLayout.LayoutParams(0, dp(56), 1f)
            if (i > 0) lp.leftMargin = dp(8)
            bgRow.addView(sw, lp)
        }
        c.addV(bgRow, 8)

        // ---- Letra ----
        c.addV(label("Tamaño de las letras", 24f, Pal.INK, true), 24)
        val fontRow = LinearLayout(this)
        fontRow.orientation = LinearLayout.HORIZONTAL
        val fcur = Look.fontIndex(this)
        for ((i, name) in Look.fontNames.withIndex()) {
            val b = smallButton(name, if (i == fcur) Pal.BLUE else Color.WHITE, if (i == fcur) Color.WHITE else Pal.INK) {
                Look.setFontIndex(this, i)
                recreate()
            }
            fontRow.addH(b, if (i == 0) 0 else 8)
        }
        c.addV(fontRow, 8)

        // ---- Brillo ----
        c.addV(label("Brillo de la pantalla", 24f, Pal.INK, true), 24)
        val auto = Switch(this)
        auto.text = "Usar el brillo del móvil"
        auto.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f * Pal.font)
        auto.setTextColor(Pal.INK)
        val bar = SeekBar(this)
        bar.max = 90
        val saved = Look.brightness(this)
        auto.isChecked = saved < 0
        bar.progress = if (saved < 0) 60 else (saved - 10).coerceIn(0, 90)
        bar.isEnabled = saved >= 0
        auto.setOnCheckedChangeListener { _, on ->
            bar.isEnabled = !on
            Look.setBrightness(this, if (on) -1 else bar.progress + 10)
            applyBrightness()
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser && !auto.isChecked) {
                    Look.setBrightness(this@AppearanceActivity, p + 10)
                    applyBrightness()
                }
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        c.addV(auto, 8)
        c.addV(bar, 8)

        // ---- Diseño ----
        c.addV(label("Diseño de los botones", 24f, Pal.INK, true), 24)
        val cols = Look.columns(this)
        val colRow = LinearLayout(this)
        colRow.orientation = LinearLayout.HORIZONTAL
        colRow.addH(smallButton("2 por fila", if (cols == 2) Pal.BLUE else Color.WHITE, if (cols == 2) Color.WHITE else Pal.INK) {
            Look.setColumns(this, 2); recreate()
        })
        colRow.addH(smallButton("1 por fila (más grandes)", if (cols == 1) Pal.BLUE else Color.WHITE, if (cols == 1) Color.WHITE else Pal.INK) {
            Look.setColumns(this, 1); recreate()
        }, 8)
        c.addV(colRow, 8)

        val colorRow = LinearLayout(this)
        colorRow.orientation = LinearLayout.HORIZONTAL
        val simple = Look.simple(this)
        colorRow.addH(smallButton("Colores", if (!simple) Pal.BLUE else Color.WHITE, if (!simple) Color.WHITE else Pal.INK) {
            Look.setSimple(this, false); recreate()
        })
        colorRow.addH(smallButton("Un solo color", if (simple) Pal.BLUE else Color.WHITE, if (simple) Color.WHITE else Pal.INK) {
            Look.setSimple(this, true); recreate()
        }, 8)
        c.addV(colorRow, 8)

        val shapeRow = LinearLayout(this)
        shapeRow.orientation = LinearLayout.HORIZONTAL
        val square = Look.square(this)
        shapeRow.addH(smallButton("Redondeados", if (!square) Pal.BLUE else Color.WHITE, if (!square) Color.WHITE else Pal.INK) {
            Look.setSquare(this, false); recreate()
        })
        shapeRow.addH(smallButton("Cuadrados", if (square) Pal.BLUE else Color.WHITE, if (square) Color.WHITE else Pal.INK) {
            Look.setSquare(this, true); recreate()
        }, 8)
        c.addV(shapeRow, 8)

        // ---- Botones del inicio ----
        c.addV(label("Botones del inicio", 24f, Pal.INK, true), 24)
        c.addV(label("Marca los que quieres ver y usa las flechas para cambiar el orden.", 19f, Pal.MUTED), 4)
        rowsBox = LinearLayout(this)
        rowsBox.orientation = LinearLayout.VERTICAL
        c.addV(rowsBox, 8)
        buildRows()

        c.addV(bigButton("Añadir otra app del móvil", Pal.GREEN) { pickApp() }, 16)
        c.addV(bigButton("Listo", Pal.BLUE) { finish() }, 12)
    }

    private fun buildRows() {
        rowsBox.removeAllViews()
        val visible = HashSet(Store.visibleApps(this))
        val list = Apps.list(this)
        for ((index, app) in list.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(12), dp(6), dp(8), dp(6))
            row.background = shape(Color.WHITE, dp(16).toFloat(), Pal.LINE, dp(2))

            val cb = CheckBox(this)
            cb.text = app.label
            cb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21f * Pal.font)
            cb.setTextColor(Pal.INK)
            cb.isChecked = visible.contains(app.id)
            cb.setOnCheckedChangeListener { _, on ->
                val now = HashSet(Store.visibleApps(this))
                if (on) now.add(app.id) else now.remove(app.id)
                Store.setVisibleApps(this, now)
                Look.setOrder(this, Look.order(this)) // avisa al inicio de que hay cambios
            }
            row.addView(cb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            row.addView(arrow(R.drawable.ic_up, "Subir ${app.label}") { move(list, index, -1) }, LinearLayout.LayoutParams(dp(48), dp(48)))
            val dl = LinearLayout.LayoutParams(dp(48), dp(48))
            dl.leftMargin = dp(6)
            row.addView(arrow(R.drawable.ic_down, "Bajar ${app.label}") { move(list, index, 1) }, dl)
            if (app.pkg != null) {
                val del = arrow(R.drawable.ic_trash, "Quitar ${app.label}") {
                    Look.removeCustom(this, app.pkg)
                    buildRows()
                }
                val ll = LinearLayout.LayoutParams(dp(48), dp(48))
                ll.leftMargin = dp(6)
                row.addView(del, ll)
            }
            rowsBox.addV(row, if (index == 0) 0 else 8)
        }
    }

    private fun arrow(res: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Pal.INK)
        b.contentDescription = desc
        b.background = shape(Color.WHITE, dp(24).toFloat(), Pal.INK, dp(2))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun move(list: List<AppDef>, index: Int, delta: Int) {
        val to = index + delta
        if (to < 0 || to >= list.size) return
        val ids = ArrayList(list.map { it.id })
        val x = ids.removeAt(index)
        ids.add(to, x)
        Look.setOrder(this, ids)
        buildRows()
    }

    /** Lista las apps instaladas para elegir una y ponerla como botón. */
    private fun pickApp() {
        try {
            val pm = packageManager
            val i = Intent(Intent.ACTION_MAIN)
            i.addCategory(Intent.CATEGORY_LAUNCHER)
            val found = pm.queryIntentActivities(i, 0)
                .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
                .filter { it.first != packageName }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
            if (found.isEmpty()) {
                toast("No encuentro apps para añadir")
                return
            }
            AlertDialog.Builder(this)
                .setTitle("Elige una app")
                .setItems(found.map { it.second }.toTypedArray()) { _, which ->
                    Look.addCustom(this, found[which].first, found[which].second)
                    buildRows()
                    toast("Añadida: " + found[which].second)
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } catch (e: Exception) {
            toast("No he podido mostrar la lista de apps")
        }
    }
}
