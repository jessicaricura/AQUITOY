package com.aquitoy.app

import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.inputmethod.EditorInfo

/** Buscar en Google escribiendo o hablando. */
class SearchActivity : BaseActivity() {
    private lateinit var q: android.widget.EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Buscar en Google")
        c.addV(label("¿Qué quieres buscar?", 24f, Pal.INK, true))
        q = input("Escribe aquí o pulsa Hablar")
        q.imeOptions = EditorInfo.IME_ACTION_SEARCH
        q.setSingleLine(true)
        q.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                search(q.text.toString())
                true
            } else {
                false
            }
        }
        c.addV(q, 8)
        c.addV(bigButton("Hablar", Pal.BLUE) { startDictation(500, "¿Qué quieres buscar?") }, 12)
        c.addV(bigButton("Buscar", Pal.INK) { search(q.text.toString()) }, 12)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 500 && resultCode == RESULT_OK) {
            val t = dictatedText(data)
            if (t != null) {
                q.setText(t)
                search(t)
            }
        }
    }

    private fun search(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        try {
            val i = Intent(Intent.ACTION_WEB_SEARCH)
            i.putExtra(SearchManager.QUERY, t)
            startActivity(i)
        } catch (e: Exception) {
            openUrl("https://www.google.com/search?q=" + Uri.encode(t))
        }
    }
}
