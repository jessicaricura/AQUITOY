package com.aquitoy.app

import android.content.Intent
import android.os.Bundle

/** Botones grandes para abrir Gmail, Hotmail/Outlook, Yahoo u otro correo. */
class EmailActivity : BaseActivity() {

    private class Provider(val name: String, val pkg: String, val web: String, val color: Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Correo")
        val providers = listOf(
            Provider("Gmail", "com.google.android.gm", "https://mail.google.com", android.graphics.Color.parseColor("#B3261E")),
            Provider("Hotmail / Outlook", "com.microsoft.office.outlook", "https://outlook.live.com/mail", android.graphics.Color.parseColor("#1456B8")),
            Provider("Yahoo", "com.yahoo.mobile.client.android.mail", "https://mail.yahoo.com", android.graphics.Color.parseColor("#6A3FA0"))
        )
        var first = true
        for (p in providers) {
            val installed = packageManager.getLaunchIntentForPackage(p.pkg) != null
            val text = if (installed) p.name else p.name + " (en el navegador)"
            c.addV(bigButton(text, p.color) {
                if (!openPackage(p.pkg)) openUrl(p.web)
            }, if (first) 0 else 14)
            first = false
        }
        c.addV(bigButton("Otro correo", Pal.INK) {
            try {
                val i = Intent(Intent.ACTION_MAIN)
                i.addCategory(Intent.CATEGORY_APP_EMAIL)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
            } catch (e: Exception) {
                toast("No encuentro otra app de correo")
            }
        }, 14)
    }
}
