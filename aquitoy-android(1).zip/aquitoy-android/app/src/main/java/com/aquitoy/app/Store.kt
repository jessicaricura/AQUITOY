package com.aquitoy.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

data class Contact(val name: String, val phone: String)

data class Reminder(
    val id: Long,
    val hour: Int,
    val minute: Int,
    val text: String,
    val daily: Boolean,
    val alarm: Boolean,
    val enabled: Boolean,
    val triggerAt: Long
)

data class Note(val id: Long, val text: String, val ts: Long)

data class Notice(
    val id: Long,
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val ts: Long
)

/** Todo lo que la app guarda en el móvil (nada sale de aquí salvo lo que se habla con Claude). */
object Store {
    private fun p(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("aquitoy", Context.MODE_PRIVATE)

    private fun arr(c: Context, key: String): JSONArray {
        return try {
            JSONArray(p(c).getString(key, "[]"))
        } catch (e: Exception) {
            JSONArray()
        }
    }

    // ---- Ajustes sencillos ----
    fun name(c: Context): String = p(c).getString("name", "") ?: ""
    fun setName(c: Context, v: String) { p(c).edit().putString("name", v).apply() }

    fun apiKey(c: Context): String = p(c).getString("apiKey", "") ?: ""
    fun setApiKey(c: Context, v: String) { p(c).edit().putString("apiKey", v).apply() }

    fun rate(c: Context): Float = p(c).getFloat("rate", 0.9f)
    fun setRate(c: Context, v: Float) { p(c).edit().putFloat("rate", v).apply() }

    fun readNotices(c: Context): Boolean = p(c).getBoolean("readNotices", false)
    fun setReadNotices(c: Context, v: Boolean) { p(c).edit().putBoolean("readNotices", v).apply() }

    fun setupDone(c: Context): Boolean = p(c).getBoolean("setupDone", false)
    fun setSetupDone(c: Context, v: Boolean) { p(c).edit().putBoolean("setupDone", v).apply() }

    // ---- Familiares (el primero es el contacto del botón de ayuda) ----
    fun family(c: Context): List<Contact> {
        val out = ArrayList<Contact>()
        for (i in 0 until 3) {
            out.add(
                Contact(
                    p(c).getString("fc_name_$i", "") ?: "",
                    p(c).getString("fc_phone_$i", "") ?: ""
                )
            )
        }
        return out
    }

    fun validFamily(c: Context): List<Contact> =
        family(c).filter { it.name.isNotBlank() && it.phone.isNotBlank() }

    fun setFamily(c: Context, list: List<Contact>) {
        val e = p(c).edit()
        for (i in 0 until 3) {
            val ct = if (i < list.size) list[i] else Contact("", "")
            e.putString("fc_name_$i", ct.name)
            e.putString("fc_phone_$i", ct.phone)
        }
        e.apply()
    }

    // ---- Apps visibles en el inicio ----
    fun visibleApps(c: Context): Set<String> {
        val s = p(c).getString("apps", null) ?: return Apps.all.map { it.id }.toSet()
        return s.split(",").filter { it.isNotBlank() }.toSet()
    }

    fun setVisibleApps(c: Context, ids: Collection<String>) {
        p(c).edit().putString("apps", ids.joinToString(",")).apply()
    }

    // ---- Memoria del asistente ----
    fun memory(c: Context): List<String> {
        val a = arr(c, "memory")
        val out = ArrayList<String>()
        for (i in 0 until a.length()) out.add(a.optString(i))
        return out
    }

    fun remember(c: Context, text: String) {
        val t = text.trim().take(160)
        if (t.isEmpty()) return
        val list = ArrayList(memory(c))
        if (list.any { it.equals(t, ignoreCase = true) }) return
        list.add(t)
        while (list.size > 30) list.removeAt(0)
        val a = JSONArray()
        list.forEach { a.put(it) }
        p(c).edit().putString("memory", a.toString()).apply()
    }

    // ---- Recordatorios y alarmas ----
    fun reminders(c: Context): List<Reminder> {
        val a = arr(c, "reminders")
        val out = ArrayList<Reminder>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(
                Reminder(
                    o.optLong("id"),
                    o.optInt("h"),
                    o.optInt("m"),
                    o.optString("text"),
                    o.optBoolean("daily"),
                    o.optBoolean("alarm"),
                    o.optBoolean("enabled", true),
                    o.optLong("at")
                )
            )
        }
        return out
    }

    fun saveReminders(c: Context, list: List<Reminder>) {
        val a = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("id", r.id)
            o.put("h", r.hour)
            o.put("m", r.minute)
            o.put("text", r.text)
            o.put("daily", r.daily)
            o.put("alarm", r.alarm)
            o.put("enabled", r.enabled)
            o.put("at", r.triggerAt)
            a.put(o)
        }
        p(c).edit().putString("reminders", a.toString()).apply()
    }

    fun reminder(c: Context, id: Long): Reminder? = reminders(c).firstOrNull { it.id == id }

    fun upsertReminder(c: Context, r: Reminder) {
        val list = ArrayList(reminders(c))
        val i = list.indexOfFirst { it.id == r.id }
        if (i >= 0) list[i] = r else list.add(r)
        saveReminders(c, list)
    }

    fun removeReminder(c: Context, id: Long) {
        saveReminders(c, reminders(c).filter { it.id != id })
    }

    // ---- Notas ----
    fun notes(c: Context): List<Note> {
        val a = arr(c, "notes")
        val out = ArrayList<Note>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(Note(o.optLong("id"), o.optString("text"), o.optLong("ts")))
        }
        return out
    }

    private fun saveNotes(c: Context, list: List<Note>) {
        val a = JSONArray()
        for (n in list) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("text", n.text)
            o.put("ts", n.ts)
            a.put(o)
        }
        p(c).edit().putString("notes", a.toString()).apply()
    }

    fun addNote(c: Context, text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        val list = ArrayList(notes(c))
        list.add(0, Note(now, t.take(2000), now))
        saveNotes(c, list)
    }

    fun removeNote(c: Context, id: Long) {
        saveNotes(c, notes(c).filter { it.id != id })
    }

    // ---- Avisos copiados de otras apps (WhatsApp, llamadas...) ----
    @Synchronized
    fun notices(c: Context): List<Notice> {
        val a = arr(c, "notices")
        val out = ArrayList<Notice>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(
                Notice(
                    o.optLong("id"),
                    o.optString("pkg"),
                    o.optString("app"),
                    o.optString("title"),
                    o.optString("text"),
                    o.optLong("ts")
                )
            )
        }
        return out
    }

    @Synchronized
    fun addNotice(c: Context, n: Notice) {
        val list = ArrayList(notices(c))
        val dup = list.firstOrNull {
            it.pkg == n.pkg && it.title == n.title && it.text == n.text && n.ts - it.ts < 5000
        }
        if (dup != null) return
        list.add(0, n)
        while (list.size > 60) list.removeAt(list.size - 1)
        saveNotices(c, list)
    }

    @Synchronized
    fun clearNotices(c: Context) {
        p(c).edit().putString("notices", "[]").apply()
    }

    private fun saveNotices(c: Context, list: List<Notice>) {
        val a = JSONArray()
        for (n in list) {
            val o = JSONObject()
            o.put("id", n.id)
            o.put("pkg", n.pkg)
            o.put("app", n.app)
            o.put("title", n.title)
            o.put("text", n.text)
            o.put("ts", n.ts)
            a.put(o)
        }
        p(c).edit().putString("notices", a.toString()).apply()
    }
}
