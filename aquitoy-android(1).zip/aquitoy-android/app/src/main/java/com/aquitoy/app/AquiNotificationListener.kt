package com.aquitoy.app

import android.app.Notification
import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Copia dentro de AQUITOY los avisos de WhatsApp, llamadas perdidas, mensajes y correo.
 * Hay que activarlo una vez en Ajustes > Acceso a notificaciones.
 */
class AquiNotificationListener : NotificationListenerService() {
    private var speaker: Speaker? = null

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return

        val extras = n.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
        val text = big ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return

        val category = n.category ?: ""
        val keep = WATCHED.contains(pkg) ||
            category == Notification.CATEGORY_MESSAGE ||
            category == Notification.CATEGORY_EMAIL ||
            category == Notification.CATEGORY_CALL ||
            category == "missed_call" ||
            category == Notification.CATEGORY_SOCIAL
        if (!keep) return

        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            pkg
        }

        Store.addNotice(
            this,
            Notice(System.currentTimeMillis(), pkg, label, title.take(80), text.take(400), System.currentTimeMillis())
        )

        if (Store.readNotices(this)) {
            val sp = speaker ?: Speaker(this)
            speaker = sp
            val phrase = if (title.isNotBlank()) "$label. $title. $text" else "$label. $text"
            sp.speak(phrase.take(300), false, null)
        }
    }

    override fun onDestroy() {
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }

    companion object {
        private val WATCHED = setOf(
            "com.whatsapp", "com.whatsapp.w4b", "org.telegram.messenger",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.android.server.telecom", "com.android.phone",
            "com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging",
            "com.google.android.gm", "com.microsoft.office.outlook",
            "com.yahoo.mobile.client.android.mail", "com.android.email"
        )
    }
}
