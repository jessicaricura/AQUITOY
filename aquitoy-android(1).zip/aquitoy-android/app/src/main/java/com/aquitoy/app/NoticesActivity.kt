package com.aquitoy.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout

/** Avisos de WhatsApp, llamadas y mensajes, reunidos dentro de AQUITOY. */
class NoticesActivity : BaseActivity() {
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Avisos")
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        c.addV(listBox)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun listenerEnabled(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return s.contains(packageName)
    }

    private fun render() {
        listBox.removeAllViews()

        if (!listenerEnabled()) {
            val warn = card()
            warn.addView(label("Para ver aquí los avisos de WhatsApp y las llamadas, hay que dar permiso una vez.", 22f, Pal.INK, true))
            warn.addV(
                bigButton("Dar permiso", Pal.AMBER) {
                    try {
                        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    } catch (e: Exception) {
                        toast("Abre Ajustes y busca Acceso a notificaciones")
                    }
                }, 12
            )
            listBox.addV(warn)
            listBox.addV(label("En la lista que aparece, activa AQUITOY y acepta.", 19f, Pal.MUTED), 10)
        }

        val items = Store.notices(this)
        if (items.isEmpty()) {
            val note = card()
            note.addView(label("No hay avisos nuevos.", 22f, Pal.MUTED))
            listBox.addV(note, 12)
            return
        }

        listBox.addV(smallButton("Borrar todos", Color.WHITE, Pal.INK) {
            Store.clearNotices(this)
            render()
        }, 8)

        for (n in items) {
            val row = card()
            row.setOnClickListener {
                if (!openPackage(n.pkg)) toast("No puedo abrir esa app")
            }
            row.addView(label(n.app + "  ·  " + formatTime(n.ts), 17f, Pal.MUTED))
            if (n.title.isNotBlank()) row.addView(label(n.title, 24f, Pal.INK, true))
            if (n.text.isNotBlank()) row.addView(label(n.text, 21f, Pal.INK))
            listBox.addV(row, 10)
        }
    }
}
