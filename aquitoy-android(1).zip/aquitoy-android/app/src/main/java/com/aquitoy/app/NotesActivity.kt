package com.aquitoy.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout

/** Notas escritas o dictadas. Tocar una nota la lee en voz alta. */
class NotesActivity : BaseActivity() {
    private lateinit var listBox: LinearLayout
    private lateinit var noteInput: EditText
    private var speaker: Speaker? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Notas")
        noteInput = input("Escribe tu nota aquí")
        noteInput.minLines = 3
        noteInput.gravity = Gravity.TOP
        c.addV(noteInput)
        c.addV(bigButton("Dictar con la voz", Pal.BLUE) { startDictation(400, "Di tu nota") }, 10)
        c.addV(bigButton("Guardar nota", Pal.GREEN) { save() }, 10)
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        c.addV(listBox, 20)
        refresh()
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 400 && resultCode == RESULT_OK) {
            val t = dictatedText(data)
            if (t != null) {
                val old = noteInput.text.toString()
                noteInput.setText(if (old.isBlank()) t else "$old $t")
                noteInput.setSelection(noteInput.text.length)
            }
        }
    }

    private fun save() {
        val t = noteInput.text.toString().trim()
        if (t.isEmpty()) {
            toast("Escribe o dicta algo primero")
            return
        }
        Store.addNote(this, t)
        noteInput.setText("")
        toast("Nota guardada")
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val notes = Store.notes(this)
        if (notes.isEmpty()) {
            val note = card()
            note.addView(label("No tienes notas.", 22f, Pal.MUTED))
            listBox.addV(note)
            return
        }
        listBox.addV(label("Toca una nota para escucharla", 18f, Pal.MUTED), 0)
        for (n in notes) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(12), dp(12), dp(12))
            row.background = ripple(shape(Color.WHITE, dp(20).toFloat(), Pal.LINE, dp(2)))
            row.setOnClickListener {
                val sp = speaker ?: Speaker(this)
                speaker = sp
                sp.speak(n.text, true, null)
            }
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(label(formatTime(n.ts), 17f, Pal.MUTED))
            tx.addView(label(n.text, 22f, Pal.INK))
            val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            row.addView(tx, tlp)
            val del = ImageButton(this)
            del.setImageResource(R.drawable.ic_trash)
            del.setColorFilter(Pal.MUTED)
            del.contentDescription = "Borrar nota"
            del.background = shape(Color.WHITE, dp(24).toFloat(), Pal.LINE, dp(2))
            del.setOnClickListener {
                Store.removeNote(this, n.id)
                refresh()
            }
            val dlp = LinearLayout.LayoutParams(dp(52), dp(52))
            dlp.leftMargin = dp(10)
            row.addView(del, dlp)
            listBox.addV(row, 10)
        }
    }

    override fun onDestroy() {
        speaker?.shutdown()
        speaker = null
        super.onDestroy()
    }
}
