package com.aquitoy.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ClaudeAction(val name: String, val input: JSONObject)

class ClaudeReply(val text: String, val actions: List<ClaudeAction>)

class ClaudeException(val code: Int, message: String) : Exception(message)

/** Habla con Claude. Bloqueante: llamar siempre desde un hilo aparte. */
object Claude {
    private const val MODEL = "claude-sonnet-5-5"

    private fun tools(): JSONArray {
        val arr = JSONArray()

        val memory = JSONObject()
        memory.put("name", "guardar_recuerdo")
        memory.put(
            "description",
            "Guarda en una frase corta un dato duradero e importante sobre la persona (familia, gustos, rutinas, salud que ella menciona, nombres) para personalizar futuras conversaciones."
        )
        memory.put(
            "input_schema",
            JSONObject()
                .put("type", "object")
                .put("properties", JSONObject().put("texto", JSONObject().put("type", "string").put("description", "El dato, en una frase corta")))
                .put("required", JSONArray().put("texto"))
        )
        arr.put(memory)

        val reminder = JSONObject()
        reminder.put("name", "crear_recordatorio")
        reminder.put(
            "description",
            "Crea un recordatorio que sonará en voz alta en el móvil de la persona. Úsalo cuando pida que le recuerdes o avises de algo a una hora concreta."
        )
        val props = JSONObject()
        props.put("hora", JSONObject().put("type", "string").put("description", "Hora en formato 24 horas HH:MM, por ejemplo 18:30"))
        props.put("texto", JSONObject().put("type", "string").put("description", "Qué hay que recordar, en pocas palabras"))
        props.put(
            "dia",
            JSONObject().put("type", "string").put("enum", JSONArray().put("hoy").put("manana")).put("description", "Día del aviso. Por defecto hoy.")
        )
        props.put("cada_dia", JSONObject().put("type", "boolean").put("description", "true si debe repetirse todos los días"))
        reminder.put(
            "input_schema",
            JSONObject().put("type", "object").put("properties", props).put("required", JSONArray().put("hora").put("texto"))
        )
        arr.put(reminder)

        val fin = JSONObject()
        fin.put("name", "fin_conversacion")
        fin.put("description", "Úsalo cuando la persona se despide o quiere terminar de hablar. Despídete también con palabras.")
        fin.put("input_schema", JSONObject().put("type", "object").put("properties", JSONObject()))
        arr.put(fin)

        return arr
    }

    private fun system(c: Context): String {
        val name = Store.name(c)
        val mem = Store.memory(c).takeLast(25)
        val rem = Store.reminders(c).filter { it.enabled }.map { String.format("%02d:%02d %s", it.hour, it.minute, it.text) }
        val fam = Store.validFamily(c).map { it.name }
        val now = SimpleDateFormat("EEEE d 'de' MMMM yyyy, HH:mm", Locale("es", "ES")).format(Date())
        val who = if (name.isBlank()) "una persona mayor" else name
        return listOf(
            "Eres AQUITOY, la compañía de voz de $who. Hablas en español de España, con cercanía, como una amiga paciente y cariñosa. Nunca la tratas como a una niña.",
            "Tus respuestas se leen en voz alta: frases cortas y naturales, entre una y cuatro frases, sin listas, sin símbolos, sin emojis y sin formato. Escribe los números y las horas como se dicen.",
            "Tu objetivo es dar buena conversación. Escucha de verdad y responde a lo que cuenta, retomando detalles que ha dicho antes. Haz una sola pregunta cada vez, abierta y sencilla, para que siga hablando: cómo ha dormido, qué ha comido, a quién ha visto, recuerdos de su juventud, su pueblo, su familia, sus gustos, la música, la cocina, el tiempo.",
            "Si contesta con pocas palabras, propón algo ameno: una adivinanza, un refrán y su significado, un juego de memoria, una anécdota corta o un recuerdo para evocar. Adapta el tono a su ánimo; si está triste, acompaña primero y no intentes animarla de golpe.",
            "Si te pregunta algo que no sabes o que depende de hoy, como noticias o resultados, dilo con sinceridad y no inventes.",
            "No eres médico. No des diagnósticos ni cambies medicaciones. Si cuenta algo grave, como dolor en el pecho, dificultad para respirar, una caída con golpe, un mareo fuerte o confusión, dile con calma que mantenga pulsado el botón rojo de PEDIR AYUDA o que llame al 112.",
            "Cuando cuente algo duradero e importante sobre ella, guárdalo con la herramienta guardar_recuerdo en una frase corta, sin avisarla, y úsalo después para personalizar la charla.",
            "Si pide que le recuerdes algo, usa crear_recordatorio y confirma en voz alta la hora. Si se despide, usa fin_conversacion y despídete con cariño.",
            "Responde siempre también con palabras, aunque uses una herramienta.",
            "Ahora es: $now.",
            "Lo que sabes de ella: " + (if (mem.isEmpty()) "todavía nada" else mem.joinToString("; ")) + ".",
            "Recordatorios pendientes: " + (if (rem.isEmpty()) "ninguno" else rem.joinToString("; ")) + ".",
            "Familiares guardados: " + (if (fam.isEmpty()) "sin datos" else fam.joinToString(", ")) + "."
        ).joinToString("\n")
    }

    /** [history] son pares (rol, texto) con rol "user" o "assistant"; el último debe ser "user". */
    fun chat(c: Context, history: List<Pair<String, String>>): ClaudeReply {
        val key = Store.apiKey(c)
        if (key.isBlank()) throw ClaudeException(0, "Falta la clave de Claude")

        val messages = JSONArray()
        for (m in history.takeLast(14)) {
            messages.put(JSONObject().put("role", m.first).put("content", m.second))
        }
        val body = JSONObject()
        body.put("model", MODEL)
        body.put("max_tokens", 400)
        body.put("system", system(c))
        body.put("tools", tools())
        body.put("messages", messages)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 40000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = if (stream != null) {
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { it.readText() }
            } else {
                ""
            }
            if (code !in 200..299) throw ClaudeException(code, "Error $code de Claude")

            val json = JSONObject(raw)
            val content = json.optJSONArray("content") ?: JSONArray()
            val text = StringBuilder()
            val actions = ArrayList<ClaudeAction>()
            for (i in 0 until content.length()) {
                val b = content.optJSONObject(i) ?: continue
                when (b.optString("type")) {
                    "text" -> {
                        if (text.isNotEmpty()) text.append(' ')
                        text.append(b.optString("text"))
                    }
                    "tool_use" -> actions.add(ClaudeAction(b.optString("name"), b.optJSONObject("input") ?: JSONObject()))
                }
            }
            return ClaudeReply(text.toString().trim(), actions)
        } finally {
            conn.disconnect()
        }
    }
}
