package com.aquitoy.app

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Asistente sin internet y sin clave: entiende órdenes sencillas (hora, día, avisos, recordatorios).
 * No conversa libremente; para eso hace falta la clave de Claude.
 */
object LocalBrain {
    private val words = mapOf(
        "una" to 1, "uno" to 1, "un" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5, "seis" to 6,
        "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "quince" to 15, "veinte" to 20, "treinta" to 30
    )

    private fun plain(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase().trim()

    private fun num(w: String): Int? = w.toIntOrNull() ?: words[w]

    private fun say(text: String) = ClaudeReply(text, emptyList())

    fun reply(c: Context, heard: String): ClaudeReply {
        val t = plain(heard)
        val now = Calendar.getInstance()

        if (Regex("\\b(adios|hasta luego|hasta pronto|nada mas|terminar|dejalo|chao)\\b").containsMatchIn(t)) {
            return ClaudeReply("Hasta pronto.", listOf(ClaudeAction("fin_conversacion", JSONObject())))
        }

        val wantsReminder = Regex("\\b(avisame|avisarme|avisa|recuerdame|recordarme|recuerda|recordatorio|alarma|despiertame|pon(me)? un aviso)\\b").containsMatchIn(t)
        if (wantsReminder) {
            val time = parseTime(t, now)
            if (time == null) {
                return say("Dime a qué hora. Por ejemplo: avísame a las cinco y media de tomar la pastilla.")
            }
            val tomorrow = heard.lowercase().contains("mañana") &&
                !Regex("(de|por|en) la mañana").containsMatchIn(heard.lowercase())
            val daily = Regex("(todos los dias|cada dia|diari)").containsMatchIn(t)
            val input = JSONObject()
            input.put("hora", String.format("%02d:%02d", time.first, time.second))
            input.put("texto", reminderText(t))
            input.put("dia", if (tomorrow) "manana" else "hoy")
            input.put("cada_dia", daily)
            return ClaudeReply("", listOf(ClaudeAction("crear_recordatorio", input)))
        }

        if (Regex("\\b(que hora|la hora|hora es)\\b").containsMatchIn(t)) {
            val h = now.get(Calendar.HOUR_OF_DAY)
            val m = now.get(Calendar.MINUTE)
            return say("Son las " + spokenTime(h, m) + ".")
        }
        if (Regex("\\b(que dia|fecha|dia es|a cuantos estamos)\\b").containsMatchIn(t)) {
            val d = SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES")).format(Date())
            return say("Hoy es $d.")
        }
        if (Regex("\\b(mis avisos|mis recordatorios|que avisos|que tengo pendiente)\\b").containsMatchIn(t)) {
            val items = Store.reminders(c).filter { it.enabled }.sortedBy { it.triggerAt }
            if (items.isEmpty()) return say("No tienes ningún aviso pendiente.")
            val txt = items.take(4).joinToString(". ") { String.format("A las %02d:%02d, %s", it.hour, it.minute, it.text) }
            return say("Tienes $txt.")
        }
        if (Regex("\\b(ayuda|socorro|me he caido|me duele|auxilio|emergencia)\\b").containsMatchIn(t)) {
            return say("Si necesitas ayuda, mantén pulsado el botón rojo de la pantalla de inicio, o llama al ciento doce.")
        }
        if (Regex("\\b(hola|buenos dias|buenas tardes|buenas noches|que tal)\\b").containsMatchIn(t)) {
            return say("Hola. Puedo decirte la hora o ponerte un aviso. ¿Qué necesitas?")
        }
        if (Regex("\\b(gracias)\\b").containsMatchIn(t)) {
            return say("De nada. Aquí estoy para lo que necesites.")
        }
        return say("No te he entendido. Puedes pedirme la hora, el día, o que te avise de algo. Por ejemplo: avísame a las cinco y media de tomar la pastilla.")
    }

    private fun spokenTime(h: Int, m: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        val part = if (h < 6) "de la madrugada" else if (h < 13) "de la mañana" else if (h < 20) "de la tarde" else "de la noche"
        val minutes = if (m == 0) "en punto" else "y $m"
        return "$h12 $minutes $part"
    }

    /** Devuelve (hora, minuto) de lo que se ha dicho, o null si no se entiende. */
    private fun parseTime(t: String, now: Calendar): Pair<Int, Int>? {
        // "en media hora", "en una hora", "en 10 minutos"
        if (Regex("\\ben media hora\\b").containsMatchIn(t)) return plusMinutes(now, 30)
        Regex("\\ben (\\w+) (minutos?|horas?)\\b").find(t)?.let {
            val n = num(it.groupValues[1])
            if (n != null) return plusMinutes(now, if (it.groupValues[2].startsWith("hora")) n * 60 else n)
        }
        var h: Int? = null
        var m = 0
        Regex("\\b(\\d{1,2})[:.](\\d{2})\\b").find(t)?.let {
            h = it.groupValues[1].toInt()
            m = it.groupValues[2].toInt()
        }
        if (h == null) {
            val r = Regex("\\ba las? (\\w+)(?: y (media|cuarto|\\w+)| menos (cuarto|\\w+)| en punto)?").find(t)
            if (r != null) {
                val base = num(r.groupValues[1])
                if (base != null) {
                    h = base
                    val plus = r.groupValues[2]
                    val minus = r.groupValues[3]
                    if (plus.isNotEmpty()) {
                        m = when (plus) {
                            "media" -> 30
                            "cuarto" -> 15
                            else -> num(plus) ?: 0
                        }
                    } else if (minus.isNotEmpty()) {
                        val less = if (minus == "cuarto") 15 else (num(minus) ?: 0)
                        h = base - 1
                        m = 60 - less
                    }
                }
            }
        }
        val hour = h ?: return null
        var hh = hour
        if (Regex("\\b(de la tarde|por la tarde|de la noche|por la noche)\\b").containsMatchIn(t) && hh in 1..11) hh += 12
        if (Regex("\\b(de la noche)\\b").containsMatchIn(t) && hh == 12) hh = 0
        if (hh < 0 || hh > 23 || m < 0 || m > 59) return null
        return Pair(hh, m)
    }

    private fun plusMinutes(now: Calendar, n: Int): Pair<Int, Int> {
        val c = now.clone() as Calendar
        c.add(Calendar.MINUTE, n)
        return Pair(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE))
    }

    private fun reminderText(t: String): String {
        var s = t
        s = s.replace(Regex("\\ben (media hora|\\w+ (minutos?|horas?))\\b"), " ")
        s = s.replace(Regex("\\ba las? \\w+( y (media|cuarto|\\w+)| menos (cuarto|\\w+)| en punto)?"), " ")
        s = s.replace(Regex("\\b\\d{1,2}[:.]\\d{2}\\b"), " ")
        s = s.replace(Regex("\\b(de la|por la) (manana|tarde|noche)\\b"), " ")
        s = s.replace(Regex("\\b(avisame|avisarme|avisa|recuerdame|recordarme|recuerda|recordatorio|alarma|despiertame|ponme|pon|un|una|aviso|manana|hoy|todos los dias|cada dia)\\b"), " ")
        s = s.replace(Regex("\\s+"), " ").trim()
        s = s.replace(Regex("^(para|que|de|a)\\s+"), "").trim()
        return if (s.isBlank()) "Aviso" else s.take(80)
    }
}
