package com.aquitoy.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Lee textos en voz alta en español. Avisa cuando termina de hablar. */
class Speaker(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var counter = 0
    private val callbacks = HashMap<String, () -> Unit>()
    private val queue = ArrayList<Triple<String, String, Boolean>>()
    private val rate: Float = Store.rate(context)

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    val t = tts
                    if (t != null) {
                        t.language = Locale("es", "ES")
                        t.setSpeechRate(rate)
                        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                            override fun onStart(utteranceId: String?) {}
                            override fun onDone(utteranceId: String?) {
                                finish(utteranceId)
                            }

                            @Deprecated("Deprecated in Java")
                            override fun onError(utteranceId: String?) {
                                finish(utteranceId)
                            }
                        })
                        ready = true
                        flushQueue()
                    }
                } else {
                    // Sin voz disponible: avisamos a quien espera para que la conversación no se quede colgada.
                    val pending = ArrayList(queue)
                    queue.clear()
                    for (item in pending) finish(item.second)
                }
            }
        }
    }

    private fun finish(id: String?) {
        if (id == null) return
        main.post {
            val cb = callbacks.remove(id)
            if (cb != null) cb()
        }
    }

    private fun flushQueue() {
        val t = tts ?: return
        val pending = ArrayList(queue)
        queue.clear()
        for (item in pending) {
            t.speak(item.first, if (item.third) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, item.second)
        }
    }

    /** Habla el texto. [onDone] se llama cuando termina (o si falla). */
    fun speak(text: String, flush: Boolean = true, onDone: (() -> Unit)? = null) {
        counter += 1
        val id = "u$counter"
        if (onDone != null) callbacks[id] = onDone
        if (!ready) {
            queue.add(Triple(text, id, flush))
            return
        }
        val t = tts
        if (t == null) {
            finish(id)
            return
        }
        val res = t.speak(text, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, id)
        if (res == TextToSpeech.ERROR) finish(id)
    }

    fun stop() {
        callbacks.clear()
        queue.clear()
        try {
            tts?.stop()
        } catch (e: Exception) {
            // nada
        }
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (e: Exception) {
            // nada
        }
        tts = null
    }
}
