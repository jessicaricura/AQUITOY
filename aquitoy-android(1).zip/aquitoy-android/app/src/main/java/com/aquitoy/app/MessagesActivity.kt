package com.aquitoy.app

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.view.ViewGroup
import android.widget.LinearLayout

/** Muestra los mensajes SMS reales del móvil (los más recientes). */
class MessagesActivity : BaseActivity() {
    private lateinit var listBox: LinearLayout
    private val names = HashMap<String, String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Mensajes")
        c.addV(bigButton("Escribir mensaje nuevo", Pal.BLUE) { openSmsApp() })
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        c.addV(listBox, 12)
        if (hasPerm(Manifest.permission.READ_SMS)) {
            load()
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_SMS, Manifest.permission.READ_CONTACTS), 300)
            showNote("Necesito permiso para leer tus mensajes. Acéptalo en la pantalla que aparece.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 300 && hasPerm(Manifest.permission.READ_SMS)) load()
    }

    private fun showNote(msg: String) {
        listBox.removeAllViews()
        val note = card()
        note.addView(label(msg, 22f, Pal.MUTED))
        listBox.addV(note)
    }

    private fun nameFor(address: String): String {
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) return address
        val cached = names[address]
        if (cached != null) return cached
        var result = address
        try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
            val cur = contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) result = cur.getString(0) ?: address
                } finally {
                    cur.close()
                }
            }
        } catch (e: Exception) {
            // nos quedamos con el número
        }
        names[address] = result
        return result
    }

    private fun load() {
        listBox.removeAllViews()
        var count = 0
        try {
            val cur = contentResolver.query(
                Uri.parse("content://sms/inbox"),
                arrayOf("address", "body", "date"),
                null, null, "date DESC"
            )
            if (cur != null) {
                try {
                    while (cur.moveToNext() && count < 30) {
                        val address = cur.getString(0) ?: "Desconocido"
                        val body = cur.getString(1) ?: ""
                        val date = cur.getLong(2)
                        addRow(address, body, date)
                        count += 1
                    }
                } finally {
                    cur.close()
                }
            }
        } catch (e: Exception) {
            showNote("No he podido leer los mensajes.")
            return
        }
        if (count == 0) showNote("No hay mensajes recibidos.")
    }

    private fun addRow(address: String, body: String, date: Long) {
        val row = card()
        row.setOnClickListener { openSmsApp(address) }
        row.addView(label(nameFor(address), 24f, Pal.INK, true))
        row.addView(label(formatTime(date), 17f, Pal.MUTED))
        val b = label(body, 21f, Pal.INK)
        b.maxLines = 4
        b.ellipsize = android.text.TextUtils.TruncateAt.END
        row.addView(b)
        listBox.addV(row, 10)
    }
}
