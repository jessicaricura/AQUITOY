package com.aquitoy.app

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.ContactsContract
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout

/** Todos los contactos del móvil. Con "call" abierto desde Llamar muestra también el 112 y la familia. */
class ContactsActivity : BaseActivity() {
    private val all = ArrayList<Contact>()
    private lateinit var listBox: LinearLayout
    private lateinit var search: EditText
    private var callMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        callMode = intent.getBooleanExtra("call", false)
        val c = makeScreen(if (callMode) "A quién llamas" else "Contactos")

        search = input("Buscar por nombre")
        c.addV(search)
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        c.addV(listBox, 8)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                render()
            }
        })

        if (hasPerm(Manifest.permission.READ_CONTACTS)) {
            load()
            render()
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 200)
            render()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            load()
            render()
        }
    }

    private fun load() {
        all.clear()
        val seen = HashSet<String>()
        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC"
        ) ?: return
        try {
            while (cursor.moveToNext()) {
                val name = cursor.getString(0) ?: continue
                val number = cursor.getString(1) ?: continue
                val key = cleanNumber(number)
                if (key.isEmpty() || !seen.add(name + key)) continue
                all.add(Contact(name, number))
            }
        } finally {
            cursor.close()
        }
    }

    private fun render() {
        listBox.removeAllViews()
        val q = search.text.toString().trim().lowercase()

        if (callMode && q.isEmpty()) {
            listBox.addV(row("112", "Emergencias", "Ambulancia, bomberos y policía", Pal.RED) { callNow("112") }, 0)
        }
        if (q.isEmpty()) {
            for (f in Store.validFamily(this)) {
                listBox.addV(row(f.name.take(1).uppercase(), f.name, f.phone + "  (familia)", Pal.GREEN) { callNow(f.phone) }, 10)
            }
        }

        val shown = all.filter { q.isEmpty() || it.name.lowercase().contains(q) }.take(250)
        if (shown.isEmpty() && all.isEmpty()) {
            val note = card()
            val msg = if (hasPerm(Manifest.permission.READ_CONTACTS))
                "No hay contactos en este móvil." else "Necesito permiso para ver tus contactos. Actívalo en Ajustes de Android."
            note.addView(label(msg, 22f, Pal.MUTED))
            listBox.addV(note, 10)
            return
        }
        for (ct in shown) {
            listBox.addV(row(ct.name.take(1).uppercase(), ct.name, ct.phone, Pal.BLUE) { callNow(ct.phone) }, 10)
        }
    }

    private fun row(initial: String, name: String, sub: String, color: Int, onCall: () -> Unit): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(14), dp(12), dp(12), dp(12))
        r.background = ripple(shape(Color.WHITE, dp(20).toFloat(), Pal.LINE, dp(2)))
        r.setOnClickListener { onCall() }

        val av = label(initial, 24f, Color.WHITE, true, true)
        av.background = shape(color, dp(28).toFloat())
        r.addView(av, LinearLayout.LayoutParams(dp(56), dp(56)))

        val tx = LinearLayout(this)
        tx.orientation = LinearLayout.VERTICAL
        tx.addView(label(name, 24f, Pal.INK, true))
        tx.addView(label(sub, 18f, Pal.MUTED))
        val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        tlp.leftMargin = dp(14)
        r.addView(tx, tlp)

        r.addView(icon(R.drawable.ic_phone, 32, color), LinearLayout.LayoutParams(dp(32), dp(32)))
        return r
    }
}
