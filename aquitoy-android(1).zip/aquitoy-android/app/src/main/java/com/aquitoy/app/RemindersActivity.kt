package com.aquitoy.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.NumberPicker
import android.util.TypedValue

/** Pantalla de alarmas (suenan) o de recordatorios (hablan). Se elige con el extra "alarm". */
class RemindersActivity : BaseActivity() {
    private var isAlarm = false
    private lateinit var listBox: LinearLayout
    private lateinit var hourPicker: NumberPicker
    private lateinit var minutePicker: NumberPicker
    private lateinit var textInput: android.widget.EditText
    private lateinit var dailyBox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        isAlarm = intent.getBooleanExtra("alarm", false)
        val c = makeScreen(if (isAlarm) "Alarma" else "Recordatorios")

        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        c.addV(listBox)

        c.addV(label(if (isAlarm) "Nueva alarma" else "Nuevo recordatorio", 24f, Pal.INK, true), 24)

        val pickers = LinearLayout(this)
        pickers.orientation = LinearLayout.HORIZONTAL
        pickers.gravity = Gravity.CENTER
        hourPicker = makePicker(23)
        minutePicker = makePicker(59)
        val cal = java.util.Calendar.getInstance()
        hourPicker.value = cal.get(java.util.Calendar.HOUR_OF_DAY)
        minutePicker.value = cal.get(java.util.Calendar.MINUTE)
        pickers.addView(hourPicker, LinearLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT))
        pickers.addView(label(":", 36f, Pal.INK, true, true), LinearLayout.LayoutParams(dp(24), ViewGroup.LayoutParams.WRAP_CONTENT))
        pickers.addView(minutePicker, LinearLayout.LayoutParams(dp(100), ViewGroup.LayoutParams.WRAP_CONTENT))
        c.addV(pickers, 8)

        textInput = input(if (isAlarm) "Nombre (por ejemplo: despertar)" else "Qué recordar (por ejemplo: tomar la pastilla)")
        c.addV(textInput, 12)

        dailyBox = CheckBox(this)
        dailyBox.text = "Todos los días"
        dailyBox.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
        dailyBox.setTextColor(Pal.INK)
        c.addV(dailyBox, 8)

        c.addV(bigButton("Añadir", Pal.BLUE) { add() }, 12)
        refresh()
    }

    private fun makePicker(max: Int): NumberPicker {
        val p = NumberPicker(this)
        p.minValue = 0
        p.maxValue = max
        p.wrapSelectorWheel = true
        p.displayedValues = Array(max + 1) { String.format("%02d", it) }
        return p
    }

    private fun add() {
        var t = textInput.text.toString().trim()
        if (t.isEmpty()) t = if (isAlarm) "Alarma" else "Aviso"
        try {
            Scheduler.create(this, hourPicker.value, minutePicker.value, t, dailyBox.isChecked, isAlarm)
            toast("Guardado")
        } catch (e: Exception) {
            ErrorLog.save(this, e)
            toast("No he podido programar el aviso")
        }
        textInput.setText("")
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val items = Store.reminders(this)
            .filter { it.alarm == isAlarm && it.enabled }
            .sortedBy { it.triggerAt }
        if (items.isEmpty()) {
            val note = card()
            note.addView(label(if (isAlarm) "No tienes alarmas." else "No tienes recordatorios.", 22f, Pal.MUTED))
            listBox.addV(note, 8)
            return
        }
        for (r in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(16), dp(12), dp(12), dp(12))
            row.background = shape(Color.WHITE, dp(20).toFloat(), Pal.LINE, dp(2))

            row.addView(label(String.format("%02d:%02d", r.hour, r.minute), 32f, Pal.INK, true),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(label(r.text, 22f, Pal.INK, true))
            tx.addView(label(if (r.daily) "Todos los días" else "Una vez", 18f, Pal.MUTED))
            val tlp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            tlp.leftMargin = dp(14)
            row.addView(tx, tlp)

            val del = android.widget.ImageButton(this)
            del.setImageResource(R.drawable.ic_trash)
            del.setColorFilter(Pal.MUTED)
            del.contentDescription = "Borrar"
            del.background = shape(Color.WHITE, dp(24).toFloat(), Pal.LINE, dp(2))
            del.setOnClickListener {
                Scheduler.delete(this, r.id)
                refresh()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(52), dp(52)))
            listBox.addV(row, 10)
        }
    }
}
