package com.aquitoy.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.math.BigDecimal
import java.math.MathContext

/** Calculadora sencilla con botones grandes. Funciona sin internet y sin otras apps. */
class CalculatorActivity : BaseActivity() {
    private lateinit var display: TextView
    private var acc: Double? = null
    private var op: Char? = null
    private var cur = ""
    private var justDone = false
    private var message: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = makeScreen("Calculadora")

        display = label("0", 44f, Pal.INK, true)
        display.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        display.setPadding(dp(16), dp(10), dp(16), dp(10))
        display.minHeight = dp(110)
        display.background = shape(Color.WHITE, dp(20).toFloat(), Pal.INK, dp(3))
        c.addV(display, 4)

        val rows = listOf(
            listOf("C", "←", "÷", "×"),
            listOf("7", "8", "9", "−"),
            listOf("4", "5", "6", "+"),
            listOf("1", "2", "3", "="),
            listOf("0", ",")
        )
        for ((r, keys) in rows.withIndex()) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for ((k, key) in keys.withIndex()) {
                val weight = if (key == "0") 3f else 1f
                val isOp = key in listOf("÷", "×", "−", "+", "=")
                val bg = when {
                    key == "=" -> Pal.GREEN
                    isOp -> Pal.BLUE
                    key == "C" || key == "←" -> Pal.RED
                    else -> Color.WHITE
                }
                val fg = if (bg == Color.WHITE) Pal.INK else Color.WHITE
                val b = bigButton(key, bg, fg, if (bg == Color.WHITE) Pal.INK else 0) { press(key) }
                b.minHeight = dp(76)
                b.minimumHeight = dp(76)
                val lp = LinearLayout.LayoutParams(0, dp(76), weight)
                if (k > 0) lp.leftMargin = dp(8)
                row.addView(b, lp)
            }
            c.addV(row, if (r == 0) 12 else 8)
        }
    }

    private fun fmt(d: Double): String {
        if (d == Math.floor(d) && Math.abs(d) < 1e12) return d.toLong().toString()
        return BigDecimal(d).round(MathContext(10)).stripTrailingZeros().toPlainString()
    }

    private fun compute(a: Double, o: Char, b: Double): Double? = when (o) {
        '+' -> a + b
        '−' -> a - b
        '×' -> a * b
        '÷' -> if (b == 0.0) null else a / b
        else -> b
    }

    private fun press(key: String) {
        message = null
        val ch = key[0]
        when {
            key == "C" -> {
                acc = null; op = null; cur = ""; justDone = false
            }
            key == "←" -> if (cur.isNotEmpty()) cur = cur.dropLast(1)
            key == "," -> {
                if (justDone) { cur = ""; justDone = false }
                if (!cur.contains('.')) cur = if (cur.isEmpty()) "0." else "$cur."
            }
            ch.isDigit() -> {
                if (justDone) { cur = ""; justDone = false }
                if (cur.length < 12) cur = if (cur == "0") key else cur + key
            }
            key == "=" -> {
                val a = acc
                val o = op
                if (a != null && o != null && cur.isNotEmpty() && cur != ".") {
                    val res = compute(a, o, cur.toDouble())
                    acc = null; op = null
                    if (res == null) {
                        cur = ""
                        message = "No se puede dividir entre cero"
                    } else {
                        cur = fmt(res)
                        justDone = true
                    }
                }
            }
            else -> { // + − × ÷
                justDone = false
                val a = acc
                val o = op
                if (cur.isNotEmpty() && cur != ".") {
                    if (a != null && o != null) {
                        val res = compute(a, o, cur.toDouble())
                        if (res == null) {
                            acc = null; op = null; cur = ""
                            message = "No se puede dividir entre cero"
                            show()
                            return
                        }
                        acc = res
                    } else {
                        acc = cur.toDouble()
                    }
                    cur = ""
                    op = ch
                } else if (a != null) {
                    op = ch
                }
            }
        }
        show()
    }

    private fun show() {
        val m = message
        if (m != null) {
            display.text = m
            return
        }
        val a = acc
        val o = op
        val text = StringBuilder()
        if (a != null && o != null) text.append(fmt(a)).append(' ').append(o).append(' ')
        text.append(if (cur.isEmpty() && text.isEmpty()) "0" else cur)
        display.text = text.toString().replace('.', ',')
    }
}
