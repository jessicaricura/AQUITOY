package com.aquitoy.app

import android.content.Context
import android.graphics.Color

/** Un botón del inicio. Si [pkg] no es null, es una app del móvil y se usa su propio icono. */
data class AppDef(val id: String, val label: String, val color: Int, val icon: Int, val pkg: String? = null)

object Apps {
    val all: List<AppDef> = listOf(
        AppDef("llamar", "Llamar", Color.parseColor("#1456B8"), R.drawable.ic_phone),
        AppDef("whatsapp", "WhatsApp", Color.parseColor("#1B6E3C"), R.drawable.ic_chat),
        AppDef("mensajes", "Mensajes", Color.parseColor("#9B2C6B"), R.drawable.ic_sms),
        AppDef("avisos", "Avisos", Color.parseColor("#B34A00"), R.drawable.ic_bell),
        AppDef("correo", "Correo", Color.parseColor("#33509E"), R.drawable.ic_mail),
        AppDef("fotos", "Fotos", Color.parseColor("#6A3FA0"), R.drawable.ic_image),
        AppDef("camara", "Cámara", Color.parseColor("#3B4A5A"), R.drawable.ic_camera),
        AppDef("contactos", "Contactos", Color.parseColor("#00696B"), R.drawable.ic_user),
        AppDef("buscar", "Buscar", Color.parseColor("#2B5A7A"), R.drawable.ic_search),
        AppDef("notas", "Notas", Color.parseColor("#7A5B00"), R.drawable.ic_note),
        AppDef("alarma", "Alarma", Color.parseColor("#8C2F39"), R.drawable.ic_alarm),
        AppDef("recordatorios", "Recordatorios", Color.parseColor("#A24A00"), R.drawable.ic_bell),
        AppDef("playstore", "Play Store", Color.parseColor("#0B6E4F"), R.drawable.ic_store),
        AppDef("youtube", "YouTube", Color.parseColor("#B3261E"), R.drawable.ic_play),
        AppDef("calculadora", "Calculadora", Color.parseColor("#4A4F57"), R.drawable.ic_calc),
        AppDef("maps", "Maps", Color.parseColor("#1D6F8C"), R.drawable.ic_map),
        AppDef("personalizar", "Personalizar", Color.parseColor("#5B4B8A"), R.drawable.ic_gear)
    )

    /** Todos los botones posibles (los de AQUITOY y las apps añadidas), en el orden elegido. */
    fun list(c: Context): List<AppDef> {
        val base = ArrayList<AppDef>(all)
        for (x in Look.custom(c)) {
            base.add(AppDef("app:" + x.first, x.second, Color.parseColor("#3B4A5A"), R.drawable.ic_apps, x.first))
        }
        val order = Look.order(c)
        if (order.isEmpty()) return base
        val rank = HashMap<String, Int>()
        for ((i, id) in order.withIndex()) rank[id] = i
        // Los que no están en la lista guardada van al final, sin perder su orden.
        return base.withIndex()
            .sortedBy { rank[it.value.id] ?: (1000 + it.index) }
            .map { it.value }
    }
}
