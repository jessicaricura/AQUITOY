# AQUITOY para Android

App nativa (Kotlin) que se convierte en la pantalla de inicio del móvil para personas mayores:
botón de ayuda (mantener 2 s + cuenta atrás de 10 s), llamadas y contactos, WhatsApp directo,
SMS reales, avisos del móvil dentro de la app, correo, notas, alarmas, recordatorios que suenan
con la app cerrada y asistente de voz con Claude.

IMPORTANTE: este proyecto está escrito pero NO se ha podido compilar ni probar en un móvil.
Puede necesitar algún pequeño arreglo la primera vez que se compile.

## Cómo conseguir el APK

### Opción A: Android Studio (alguien con ordenador, 15 minutos)
1. Instalar Android Studio. Abrir la carpeta `aquitoy-android`.
2. Esperar a que termine la sincronización de Gradle.
3. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Pasar `app/build/outputs/apk/debug/app-debug.apk` al móvil e instalarlo.

### Opción B: GitHub (sin Android Studio)
1. Crear un repositorio en GitHub y subir TODO el contenido de esta carpeta (incluida `.github`).
2. Pestaña Actions > "Build APK" > Run workflow.
3. Al terminar, descargar el artefacto `AQUITOY-apk`, descomprimir e instalar `app-debug.apk`.

## Primer uso en el móvil
1. Permitir "instalar apps desconocidas" para instalar el APK.
2. Al abrir, rellenar nombre, familiares y la clave de Claude (los datos quedan solo en el móvil).
3. En Ajustes (engranaje, mantener pulsado) usar los 5 botones de permisos:
   permisos, acceso a notificaciones, pantalla completa, batería sin restricciones y
   "Usar AQUITOY como pantalla de inicio".
4. Android 13+ puede pedir "Permitir ajustes restringidos" en la ficha de la app
   (Ajustes > Aplicaciones > AQUITOY > ⋮) antes de dejar activar notificaciones o SMS.

## Límites
- Leer SMS y notificaciones no se admite en Google Play: solo instalación directa (APK).
- El asistente necesita internet y el reconocimiento de voz de Google instalado.
- Los avisos exactos funcionan con la app cerrada; algunas marcas (Xiaomi, Huawei...) exigen
  desactivar el ahorro de batería de la app.
